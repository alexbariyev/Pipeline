<?php
	include('inc/config.php'); 
	include('inc/functions.php'); 
	if(isset($_GET['action']) && $_GET['action'] == 'edit'){
		$html = '';
		$page_id = $_POST['page_id'];
		$position = $_POST['position'];
		$phase = $_POST['phase'];
		$data = get_cell_content($_POST['cell_content_id']);
		$name = (!empty($data['name']) && $data['name'] != 'none')?html_entity_decode($data['name'], ENT_NOQUOTES, "UTF-8"):'';
		$bgColor = (!empty($data['bgColor']) && $data['bgColor'] != 'none')?html_entity_decode($data['bgColor'], ENT_NOQUOTES, "UTF-8"):'';
		$triangle = (!empty($data['triangle']) && $data['triangle'] != 'none')?html_entity_decode($data['triangle'], ENT_NOQUOTES, "UTF-8"):'';
		$animation = (!empty($data['animation']))?$data['animation']:'on';
		$toolTip = (!empty($data['toolTip']) && $data['toolTip'] != 'none')?html_entity_decode($data['toolTip'], ENT_NOQUOTES, "UTF-8"):'';
		$box_title = (!empty($data['box_title']) && $data['box_title'] != 'none')?html_entity_decode($data['box_title'], ENT_NOQUOTES, "UTF-8"):'';
		$description = (!empty($data['description']) && $data['description'] != 'none')?html_entity_decode($data['description'], ENT_NOQUOTES, "UTF-8"):'';
		$overBgColor = (!empty($data['overBgColor']) && $data['overBgColor'] != 'none')?html_entity_decode($data['overBgColor'], ENT_NOQUOTES, "UTF-8"):'';
		$cell_content_id = !empty($data['cell_content_id'])?$data['cell_content_id']:'';
		$business_area = !empty($data['business_area'])?$data['business_area']:'';
		$display_business = !empty($data['display_business'])?$data['display_business']:'';
		
		// new addition
		$news_box = (!empty($data['news_box']) && $data['news_box'] != 'none')?html_entity_decode($data['news_box'], ENT_NOQUOTES, "UTF-8"):'';
		
		$pages = get_pages();
		$molecule_legend = get_molecule_legend();
		$html .= '<div class="edit-cell-wrapper">';
			$html .= '<form method="post" action="' . $site_url . 'ajax.php?action=save_cell" name="form_edit_cell" id="form_edit_cell">';
				$html .= '<div class="edit_cell_title">Edit info</div>';
					$html .= '<div class="cell-pages">';
						foreach($pages as $p){
							$checked = '';
							if(in_array($p['page_id'], $data['pages'])){
								$checked = ' checked="checked"';
							}
							if($p['page_id'] == 1 && empty($cell_content_id)){
								$checked = ' checked="checked"';
							}
							$html .= '<label>';
								$html .= "<span>{$p['page_name']}</span>";
								$html .= "<input type='checkbox' name='pages[]' value='{$p['page_id']}' $checked />";
							$html .= '</label>';
						}
					$html .= '</div>';
				$html .= '<p>';
					$html .= '<label>Cell text:</label>';
					//$html .= "<input class='textCell' type='text' name='name' id='name' value='".$name."' />";
					$html .= "<textarea style='height: 20px;' class='textCell' name='name' id='name' />" . $name . '</textarea>';
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Cell Type:</label>';
					$html .= "<select name='bgColor' id='bgColor'>";
						$html .= "<option value='none'>None</option>";
						$html .= "<option value='nme'";
							if($bgColor == 'nme'){
								$html .= " selected='selected'";
							}
						$html .= ">NME</option>";
						$html .= "<option value='nilex'";
							if($bgColor == 'nilex'){
								$html .= " selected='selected'";
							}
						$html .= ">Select NILEX</option>";
						$html .= "<option value='diagnostic'";
							if($bgColor == 'diagnostic'){
								$html .= " selected='selected'";
							}
						$html .= ">Diagnostic</option>";
					$html .= "</select>";
					/*
					$html .= "<input class='textCell' type='text' name='bgColor' id='bgColor' value='".$bgColor."' />";
					$html .= "<span style='background-color: #$bgColor'>&nbsp;</span>";
					*/
				$html .= '</p>';
				/*
				$html .= '<p>';
					$html .= '<label>Hover Bg color:</label>';
					$html .= "<input class='textCell' type='text' name='overBgColor' id='overBgColor' value='".$overBgColor."' />";
					$html .= "<span style='background-color: #$overBgColor'>&nbsp;</span>";
				$html .= '</p>';
				*/
				$html .= '<p>';
					$html .= '<label>Molecule type:</label>';
					$html .= "<select name='triangle' id='triangle'>";
						$html .= "<option value='none'>None</option>";
						if(!empty($molecule_legend)){
							foreach($molecule_legend as $m){
								$html .= "<option value='{$m['legend_identifier']}'";
									if($triangle == $m['legend_identifier']){
										$html .= " selected='selected'";
									}
								$html .= ">{$m['legend_name']}</option>";
							}
						}
					$html .= "</select>";
					/*
					$html .= "<input class='textCell' type='text' name='triangle' id='triangle' value='".$triangle."' />";
					$html .= "<span style='background-color: #$triangle'>&nbsp;</span>";
					*/
				$html .= '</p>';
				/*
				$html .= '<p>';
					$html .= '<label>Animation:</label>';
					if($animation == 'on'){
						$html .= "On <input type='radio' name='animation' value='on' checked='checked' />";
						$html .= "Off <input type='radio' name='animation' value='off' />";
					}
					else {
						$html .= "On <input type='radio' name='animation' value='on' />";
						$html .= "Off <input type='radio' name='animation' value='off' checked='checked' />";
					}
				$html .= '</p>';
				*/
				$html .= '<p>';
					$html .= '<label>Tool tip:</label>';
					//$html .= "<input class='textCell' type='text' name='toolTip' id='toolTip' value='".$toolTip."' />";
					$html .= "<textarea style='height: auto;' class='textCell' name='toolTip' id='toolTip' />" . $toolTip . '</textarea>';
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Box title:</label>';
					//$html .= "<input class='textCell' type='text' name='box_title' id='box_title' value='".$box_title."' />";
					$html .= "<textarea style='height: 20px;' class='textCell' name='box_title' id='box_title' />" . $box_title . '</textarea>';
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Description:</label>';
					$html .= "<textarea name='description' id='description'>". $description . "</textarea>";
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>News Box:</label>';
					$html .= "<textarea class='tinyMce' name='news_box' id='news_box'>". $news_box . "</textarea>";
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Cell type:</label>';
					$html .= "<select name='business_area' id='business_area'>";
						$html .= "<option value=''>None</option>";
						$html .= "<option value='Oncology'";
							if($business_area == 'Oncology'){
								$html .= " selected='selected'";
							}
						$html .= ">Oncology</option>";
						$html .= "<option value='Bio-Medicines'";
							if($business_area == 'Bio-Medicines'){
								$html .= " selected='selected'";
							}
						$html .= ">Bio Medicines</option>";
						$html .= "<option value='Diabetes'";
							if($business_area == 'Diabetes'){
								$html .= " selected='selected'";
							}
						$html .= ">Diabetes</option>";
						$html .= "<option value='Research'";
							if($business_area == 'Research'){
								$html .= " selected='selected'";
							}
						$html .= ">Research</option>";
					$html .= "</select>";
				$html .= '</p>';
				$html .= "<table class='display' cellspacing='0' cellpadding='0'><tr><td><input type='checkbox' name='display_business' id='display_business'";
					if($display_business == 1) {
						$html .= " checked='checked'";
					}
				$html .= "/></td><td><label style='font-size:11px;'>Display \"Business area\":</label></td></tr></table>";
				$html .= '<p>';
					$html .= "<input type='submit' name='save_cell' id='save_cell' value='Save' />";
					/*
					if(empty($cell_content_id)){
						$html .= "<input type='button' name='save_cell' id='save_cell' onclick='checkPagesPosition(); return false;' value='Save' />";
					}
					else{
						$html .= "<input type='submit' name='save_cell' id='save_cell' value='Save' />";
					}
					*/
					$html .= "<input type='button' name='cancel' id='cancel' onclick='hidePopup(); return false;' value='Cancel' />";
				$html .= '</p>';
				$html .= "<input type='hidden' name='position' id='position' value='$position' />";
				$html .= "<input type='hidden' name='cell_content_id' id='cell_content_id' value='$cell_content_id' />";
				$html .= "<input type='hidden' name='page_id' id='page_id' value='$page_id' />";
				$html .= "<input type='hidden' name='phase' id='phase' value='$phase' />";
				$html.='<p class="errors"></div>';
			$html .= '</form>';
		$html .= '</div>';
		die($html);
	}
	if(isset($_GET['action']) && $_GET['action'] == 'save_cell'){
		$page_id = $_POST['page_id'];
		$position = $_POST['position'];
		$phase = (!empty($_POST['phase'])) ? $_POST['phase'] : '';
		$name = (!empty($_POST['name']))?mysql_real_escape_string(htmlentities($_POST['name'], ENT_NOQUOTES, "UTF-8")):'';
		$bgColor = (!empty($_POST['bgColor']))?mysql_real_escape_string(htmlentities($_POST['bgColor'], ENT_NOQUOTES, "UTF-8")):'';
		$triangle = (!empty($_POST['triangle']))?mysql_real_escape_string(htmlentities($_POST['triangle'], ENT_NOQUOTES, "UTF-8")):'none';
		$animation = (!empty($_POST['animation']))?mysql_real_escape_string($_POST['animation']):'on';
		$toolTip = (!empty($_POST['toolTip']))?mysql_real_escape_string(htmlentities($_POST['toolTip'], ENT_NOQUOTES, "UTF-8")):'none';
		$box_title = (!empty($_POST['box_title']))?mysql_real_escape_string(htmlentities($_POST['box_title'], ENT_NOQUOTES, "UTF-8")):'';
		$description = (!empty($_POST['description']))?mysql_real_escape_string(htmlentities($_POST['description'], ENT_NOQUOTES, "UTF-8")):'';
		$news_box = (!empty($_POST['news_box']) && $_POST['news_box'] != 'none')?mysql_real_escape_string($_POST['news_box']):''; // new addition 07.03.2013
		$overBgColor = (!empty($_POST['overBgColor']))?mysql_real_escape_string(htmlentities($_POST['overBgColor'], ENT_NOQUOTES, "UTF-8")):'';
		$cell_content_id = (!empty($_POST['cell_content_id']))?$_POST['cell_content_id']:'';
		$business_area = (!empty($_POST['business_area']))?$_POST['business_area']:'';
		$display_business = (!empty($_POST['display_business']))?1:0;
		if(!empty($name) && !empty($bgColor)){
			if(!empty($position)){
				if(!empty($cell_content_id)){
					mysql_query("UPDATE cells_content SET name='$name', bgColor='$bgColor', triangle='$triangle', animation='$animation', toolTip='$toolTip', box_title='$box_title', description='$description', news_box='$news_box', overBgColor='$overBgColor', business_area = '$business_area', display_business = '$display_business' WHERE cell_content_id = $cell_content_id");
				}
				else{
					mysql_query("INSERT INTO cells_content(name, bgColor, triangle, animation, toolTip, box_title, description, news_box, overBgColor, business_area, display_business) VALUES ('$name', '$bgColor', '$triangle', '$animation', '$toolTip', '$box_title', '$description', '$news_box', '$overBgColor', '$business_area', '$display_business')");
					$cell_content_id = mysql_insert_id();
				}
				
			}
			mysql_query("DELETE FROM `cell_pages` WHERE `cell_id` = '$cell_content_id'");
			if(!empty($_POST['pages'])){
				$selected_pages = join(',', $_POST['pages']);
				mysql_query("DELETE FROM `cell_page_postitions` WHERE `cell_id` = '$cell_content_id' AND page_id NOT IN ({$selected_pages})");
				
				foreach($_POST['pages'] as $p){
					mysql_query("INSERT INTO `cell_pages`(`cell_id`, `page_id`) VALUES('$cell_content_id', '$p')");
					// check if cell position for this page exists and if does not exists insert position
					$q = mysql_query("
						SELECT cell_page_postitions.cell_page_position_id
						FROM cell_page_postitions
						WHERE cell_page_postitions.page_id = '{$p}'
						AND cell_page_postitions.cell_id = '{$cell_content_id}'
						LIMIT 1
					");
					if(mysql_num_rows($q) == 0){
						// check if position is availbale
						$q = mysql_query("
							SELECT cell_page_postitions.cell_page_position_id
							FROM cell_page_postitions
							WHERE cell_page_postitions.page_id = '{$p}'
							AND cell_page_postitions.position = '{$position}'
							LIMIT 1
						");
						if(mysql_num_rows($q) == 0){
							mysql_query("INSERT INTO `cell_page_postitions`(`cell_id`, `page_id`, `position`) VALUES('$cell_content_id', '$p', '$position')");
						}
						else{
							// position is not available insert in an available position
							switch($phase){
								case 'regulatory':
									$min = 1;
									$max = 6;
									break;
								case 'nilex':
									$min = 7;
									$max = 36;
									break;
								case 'phase-3':
									$min = 37;
									$max = 48;
									break;
								case 'phase-2':
									$min = 49;
									$max = 84;
									break;
								case 'phase-1':
									$min = 85;
									$max = 120;
									break;
							}
							for($i = $min; $i <= $max; $i++){
								$q = mysql_query("
									SELECT cell_page_postitions.cell_page_position_id
									FROM cell_page_postitions
									WHERE cell_page_postitions.page_id = '{$p}'
									AND cell_page_postitions.position = '{$i}'
									LIMIT 1
								");
								if(mysql_num_rows($q) == 0){
									mysql_query("INSERT INTO `cell_page_postitions`(`cell_id`, `page_id`, `position`) VALUES('$cell_content_id', '$p', '$i')");
									break;
								}
							}
						}
					}
				}
			}
			header("Location: {$site_url}index.php?page_id=$page_id");
			
		}
		header("Location: {$site_url}index.php?page_id=$page_id");
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'delete_cell'){
		$cell_content_id = $_POST['cell_content_id'];
		if(!empty($cell_content_id)){
			mysql_query("DELETE FROM cells_content WHERE cell_content_id = '$cell_content_id'");
			mysql_query("DELETE FROM cell_pages WHERE cell_id = '$cell_content_id'");
			mysql_query("DELETE FROM cell_page_postitions WHERE cell_id = '$cell_content_id'");
		}
		echo 'ok';
		die();
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'add_edit_attrition'){
		$data = array();
		$data['pages'] = array();
		$html = '';
		$page_id = $_POST['page_id'];
		if(!empty($_POST['attrition_content_id'])){
			$title = 'Edit';
			$data = get_attrition_content($_POST['attrition_content_id']);
			$name = (!empty($data['name']) && $data['name'] != 'none')?$data['name']:'';
			$bgColor = (!empty($data['bgColor']) && $data['bgColor'] != 'none')?$data['bgColor']:'';
			$triangle = (!empty($data['triangle']) && $data['triangle'] != 'none')?$data['triangle']:'';
			$toolTip = (!empty($data['toolTip']) && $data['toolTip'] != 'none')?$data['toolTip']:'';
			$box_title = (!empty($data['box_title']) && $data['box_title'] != 'none')?$data['box_title']:'';
			$description = (!empty($data['description']) && $data['description'] != 'none')?$data['description']:'';
			$overBgColor = (!empty($data['overBgColor']) && $data['overBgColor'] != 'none')?$data['overBgColor']:'';
			$attrition_content_id = !empty($data['attrition_content_id'])?$data['attrition_content_id']:'';
		}
		else {
			$title = 'Add';
			$name = '';
			$bgColor = '';
			$triangle = '';
			$toolTip = '';
			$description = '';
			$overBgColor = '';
			$attrition_content_id = 0;
		}
		$pages = get_pages();
		$html .= '<div class="edit-cell-wrapper">';
			$html .= '<form method="post" action="' . $site_url . 'ajax.php?action=save_attrition" name="form_edit_cell" id="form_edit_cell">';
				$html .= "<div class='edit_cell_title'>$title attrition</div>";
				$html .= '<div class="cell-pages">';
						foreach($pages as $p){
							$checked = '';
							if(in_array($p['page_id'], $data['pages'])){
								$checked = ' checked="checked"';
							}
							$html .= '<label>';
								$html .= "<span>{$p['page_name']}</span>";
								$html .= "<input type='checkbox' name='pages[]' value='{$p['page_id']}' $checked />";
							$html .= '</label>';
						}
					$html .= '</div>';
				$html .= '<p>';
					$html .= '<label>Cell title:</label>';
					$html .= "<input class='textCell' type='text' name='name' id='name' value='$name' />";
				$html .= '</p>';
				
				$html .= '<p>';
					$html .= "<select name='bgColor' id='bgColor'>";
						$html .= "<option value='none'>None</option>";
						$html .= "<option value='nme'";
							if($bgColor == 'nme'){
								$html .= " selected='selected'";
							}
						$html .= ">NME</option>";
						$html .= "<option value='nilex'";
							if($bgColor == 'nilex'){
								$html .= " selected='selected'";
							}
						$html .= ">Select NILEX</option>";
						$html .= "<option value='diagnostic'";
							if($bgColor == 'diagnostic'){
								$html .= " selected='selected'";
							}
						$html .= ">Diagnostic</option>";
					$html .= "</select>";
				$html .= '</p>';
				/*
				$html .= '<p>';
					$html .= '<label>Bg color:</label>';
					$html .= "<input class='textCell' type='text' name='bgColor' id='bgColor' value='$bgColor' />";
					$html .= "<span style='background-color: #$bgColor'>&nbsp;</span>";
				$html .= '</p>';
				*/
				/*
				$html .= '<p>';
					$html .= '<label>Hover Bg color:</label>';
					$html .= "<input class='textCell' type='text' name='overBgColor' id='overBgColor' value='$overBgColor' />";
					$html .= "<span style='background-color: #$overBgColor'>&nbsp;</span>";
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>triangle:</label>';
					$html .= "<input class='textCell' type='text' name='triangle' id='triangle' value='$triangle' />";
					$html .= "<span style='background-color: #$triangle'>&nbsp;</span>";
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Tool tip:</label>';
					$html .= "<input class='textCell' type='text' name='toolTip' id='toolTip' value='$toolTip' />";
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Box title:</label>';
					$html .= "<input class='textCell' type='text' name='box_title' id='box_title' value='$box_title' />";
				$html .= '</p>';
				$html .= '<p>';
					$html .= '<label>Description:</label>';
					$html .= "<textarea name='description' id='description'>$description</textarea>";
				$html .= '</p>';
				
				*/
				// putting hidden fields
				$html .= "<input type='hidden' name='overBgColor' id='overBgColor' value='' />";
				$html .= "<input type='hidden' name='triangle' id='triangle' value='' />";
				$html .= "<input type='hidden' name='toolTip' id='toolTip' value='' />";
				$html .= "<input type='hidden' name='box_title' id='box_title' value='' />";
				$html .= "<input type='hidden' name='description' id='description' value='' />";
				
				
				$html .= '<p>';
					$html .= "<input type='submit' name='save_cell' id='save_cell' value='Save' />";
					$html .= "<input type='button' name='cancel' id='cancel' onclick='hidePopup(); return false;' value='Cancel' />";
				$html .= '</p>';
				$html .= "<input type='hidden' name='page_id' id='page_id' value='$page_id' />";
				$html .= "<input type='hidden' name='attrition_content_id' id='attrition_content_id' value='$attrition_content_id' />";
			$html .= '</form>';
			//$html .= get_legend();
		$html .= '</div>';
		die($html);
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_attrition'){
		
		$page_id = $_POST['page_id'];
		$name = (!empty($_POST['name']))?mysql_real_escape_string($_POST['name']):'';
		$bgColor = (!empty($_POST['bgColor']))?mysql_real_escape_string($_POST['bgColor']):'';
		$triangle = (!empty($_POST['triangle']))?mysql_real_escape_string($_POST['triangle']):'none';
		$toolTip = (!empty($_POST['toolTip']))?mysql_real_escape_string($_POST['toolTip']):'none';
		$box_title = (!empty($_POST['box_title']))?mysql_real_escape_string($_POST['box_title']):'';
		$description = (!empty($_POST['description']))?mysql_real_escape_string($_POST['description']):'none';
		$overBgColor = (!empty($_POST['overBgColor']))?mysql_real_escape_string($_POST['overBgColor']):'';
		$attrition_content_id = (!empty($_POST['attrition_content_id']))?$_POST['attrition_content_id']:'';
		if(!empty($attrition_content_id)){
			
			mysql_query("UPDATE attritions_content SET page_id='$page_id', name='$name', bgColor='$bgColor', triangle='$triangle', toolTip='$toolTip', box_title='$box_title', description='$description', overBgColor='$overBgColor' WHERE attrition_content_id = $attrition_content_id");
		}
		else{
			mysql_query("INSERT INTO attritions_content(page_id, name, bgColor, triangle, toolTip, box_title, description, overBgColor) VALUES ('$page_id', '$name', '$bgColor', '$triangle', '$toolTip', '$box_title', '$description', '$overBgColor')");
			$attrition_content_id = mysql_insert_id();
		}
		mysql_query("DELETE FROM `attrition_pages` WHERE `attrition_id` = '$attrition_content_id'");
		if(!empty($_POST['pages'])){
			foreach($_POST['pages'] as $p){
				mysql_query("INSERT INTO `attrition_pages`(`page_id`, `attrition_id`) VALUES('$p', '$attrition_content_id')");
			}
		}
		header("Location: {$site_url}index.php?page_id=$page_id");
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'delete_attrition'){
		$attrition_content_id = $_POST['attrition_content_id'];
		if(!empty($attrition_content_id)){
			mysql_query("DELETE FROM attrition_pages WHERE attrition_id = '$attrition_content_id'");
			mysql_query("DELETE FROM attritions_content WHERE attrition_content_id = '$attrition_content_id'");
		}
		echo 'ok';
		die();
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_page_description'){
		
		$page_id = $_POST['page_id'];
		$page_description = mysql_real_escape_string($_POST['page_description']);
		if(!empty($page_id)){
			mysql_query("UPDATE `pages` SET `page_description` = '$page_description' WHERE `page_id` = '$page_id'");
		}
		header("Location: {$site_url}index.php?page_id=$page_id");
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_page_title'){
		$page_id = $_POST['page_id'];
		foreach($_POST as $key => $value){
			mysql_query("UPDATE `general_information` SET `value` = '{$value}' WHERE `name` = '{$key}'");
		}
		header("Location: {$site_url}index.php?page_id=$page_id");
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_page_attrition_description'){
		
		$page_id = $_POST['page_id'];
		$page_attrition_description = mysql_real_escape_string($_POST['page_attrition_description']);
		if(!empty($page_id)){
			mysql_query("UPDATE `pages` SET `page_attrition_description` = '$page_attrition_description' WHERE `page_id` = '$page_id'");
		}
		header("Location: {$site_url}index.php?page_id=$page_id");
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_full_legend_description'){
		
		$full_legend_description = mysql_real_escape_string($_POST['full_legend_description']);
		mysql_query("UPDATE `full_legend` SET `content` = '$full_legend_description' WHERE `name` = 'description'");
		
		header("Location: {$site_url}index.php?full_legend");
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_general_information'){
		foreach($_POST as $key => $value){
			mysql_query("UPDATE general_information SET value = '$value' WHERE name = '$key'");
		}
		header("Location: {$site_url}index.php?page_id=" . $_GET['page_id']);
	}
	
	if(isset($_GET['action']) && ($_GET['action'] == 'save_pipeline_info' || $_GET['action'] == 'save_clinical_trials' || $_GET['action'] == 'save_analytics')){
		foreach($_POST as $key => $value){
			$value = mysql_real_escape_string($value);
			mysql_query("UPDATE general_information SET value = '$value' WHERE name = '$key'");
		}
		if($_GET['action'] == 'save_clinical_trials'){
			header("Location: {$site_url}index.php?clinical_trials");
		}
		if($_GET['action'] == 'save_pipeline_info'){
			header("Location: {$site_url}index.php?pipeline_info");
		}
		if($_GET['action'] == 'save_analytics'){
			header("Location: {$site_url}index.php?analytics");
		}
		
	}
	
	if(isset($_GET['action']) && ($_GET['action'] == 'save_full_legend')){

		foreach($_POST as $key => $value){
			$value = mysql_real_escape_string($value);
			mysql_query("UPDATE full_legend SET content = '$value' WHERE name = '$key'");
		}
		
		header("Location: {$site_url}index.php?full_legend");
		
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'edit_attrition_molecules_description'){
		$html = '';
		$page_id = $_POST['page_id'];
		$sql = mysql_query("SELECT value FROM `general_information` WHERE `name` = 'attrition_molecules_description'");
		if(mysql_num_rows($sql)){
			$res = mysql_fetch_array($sql);
			$description = $res['value'];
		}
		else {
			$description = '';
		}
		$html .= '<div class="edit-cell-wrapper">';
			$html .= '<form method="post" action="' . $site_url . 'ajax.php?&action=save_attrition_description" name="form_edit_cell" id="form_edit_cell">';
				$html .= "<div class='edit_cell_title'>Edit attrition description</div>";
				$html .= '<p>';
					$html .= '<label>Description:</label>';
					$html .= "<textarea name='attrition_molecules_description' id='attrition_molecules_description'>$description</textarea>";
				$html .= '</p>';
				$html .= '<p>';
					$html .= "<input type='submit' name='save_attrition_molecules_description' id='save_attrition_molecules_description' value='Save' />";
					$html .= "<input type='button' name='cancel' id='cancel' onclick='hidePopup(); return false;' value='Cancel' />";
				$html .= '</p>';
				$html .= "<input type='hidden' name='page_id' id='page_id' value='$page_id' />";
			$html .= '</form>';
		$html .= '</div>';
		die($html);
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_attrition_description'){
		foreach($_POST as $key => $value){
			mysql_query("UPDATE general_information SET value = '$value' WHERE name = '$key'");
		}
		header("Location: {$site_url}index.php?page_id=" . $_POST['page_id']);
	}
	/*
	if(isset($_GET['action']) && $_GET['action'] == 'change_regulatory_position'){
		$from = $_POST['from'];
		$i = 0;
		$to = $_POST['to'];
		foreach($_POST['cell_position'] as $c){
			if(!empty($_POST['cell_content_id'][$i])){
				mysql_query("UPDATE `cells_content` SET `position` = $from WHERE `cell_content_id` = {$_POST['cell_content_id'][$i]}");
			}
			$from++;
			$i++;
			
		}
	}
	*/
	if(isset($_GET['action']) && $_GET['action'] == 'change_cell_position'){
		$dragged_position = end(explode('-', $_POST['dragged_position']));
		$dropped_position = end(explode('-', $_POST['dropped_position']));
		$page_id = $_POST['page_id'];
		
		$result = array();
		
		//check if dragged position exists
		$sql_dragged = mysql_query("
							SELECT cell_page_position_id, cell_content_id, name, bgColor, triangle, cell_page_postitions.position
							FROM cells_content 
							INNER JOIN cell_page_postitions ON cells_content.cell_content_id = cell_page_postitions.cell_id AND cell_page_postitions.page_id = $page_id
							WHERE cell_page_postitions.position = $dragged_position
		");
		/*
		//check if dragged position exists
		$sql_dragged = mysql_query("SELECT * FROM cells_content WHERE position = $dragged_position");
		*/
		if(mysql_num_rows($sql_dragged)){
			$dragged = mysql_fetch_array($sql_dragged);
			$result['dragged_id'] = $dragged['cell_content_id'];
			$result['dragged_name'] = $dragged['name'];
			$result['dragged_bgColor'] = $dragged['bgColor'];
			$result['dragged_triangle'] = ($dragged['triangle']!='none')?$dragged['triangle']:'';
			$result['dragged_position'] = $dragged['position'];
			
		}
		else{
			$result['dragged_id'] = '';
			$result['dragged_name'] = '';
			$result['dragged_bgColor'] = 'empty';
			$result['dragged_triangle'] = '';
			$result['dragged_position'] = $dragged_position;
		}
		
		$sql_dropped = mysql_query("
							SELECT cell_page_position_id, cell_content_id, name, bgColor, triangle, cell_page_postitions.position
							FROM cells_content 
							INNER JOIN cell_page_postitions ON cells_content.cell_content_id = cell_page_postitions.cell_id AND cell_page_postitions.page_id = $page_id
							WHERE cell_page_postitions.position = $dropped_position
		");
		/*
		$sql_dropped = mysql_query("SELECT * FROM cells_content WHERE position = $dropped_position");
		*/
		
		if(mysql_num_rows($sql_dropped)){
			$dropped = mysql_fetch_array($sql_dropped);
			$result['dropped_id'] = $dropped['cell_content_id'];
			$result['dropped_name'] = $dropped['name'];
			$result['dropped_bgColor'] = $dropped['bgColor'];
			$result['dropped_triangle'] = ($dropped['triangle']!='none')?$dropped['triangle']:'';
			$result['dropped_position'] = $dropped['position'];
		}
		else{
			$result['dropped_id'] = '';
			$result['dropped_name'] = '';
			$result['dropped_bgColor'] = 'empty';
			$result['dropped_triangle'] = '';
			$result['dropped_position'] = $dropped_position;
		}
		if(mysql_num_rows($sql_dragged)){
			mysql_query("UPDATE cell_page_postitions SET position = $dropped_position WHERE cell_page_position_id = {$dragged['cell_page_position_id']}");
		}
		if(mysql_num_rows($sql_dropped)){
			mysql_query("UPDATE cell_page_postitions SET position = $dragged_position WHERE cell_page_position_id = {$dropped['cell_page_position_id']}");
		}

		if(($_POST['dragged_phase'] != $_POST['dropped_phase']) && ($result['dropped_id'] != '' || $result['dragged_id'] != '')){
			reorder_positions();
		}
		
		
		echo json_encode($result);
		
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'import_positions'){
		// get all pages 
		$query_1 = mysql_query('SELECT page_id, page_name FROM `pages` ORDER BY `page_id` ASC');
		echo 'Getting pages to update position....<br />';
		if(mysql_num_rows($query_1)){
			while($res = mysql_fetch_array($query_1)){
				echo 'Updating cell positions for page: ' . $res['page_name'] . '...';
				$sql = sprintf("SELECT cell_id, position
							FROM cell_pages INNER JOIN cells_content ON cells_content.cell_content_id = cell_pages.cell_id
							WHERE cell_pages.page_id = %d
							ORDER BY position ASC",
							$res['page_id']);
				$query_2 = mysql_query($sql);
				if(mysql_num_rows($query_2)){
					while($r = mysql_fetch_array($query_2)){
						// check if page_position exists in database
						$sql = sprintf("SELECT `cell_page_position_id` 
									FROM `cell_page_postitions` 
									WHERE (`cell_id` = '%d' AND `page_id` = '%d' AND `position` = '%d')"
								, $r['cell_id'], $res['page_id'], $r['position']);
						$query_3 = mysql_query($sql);
						if(mysql_num_rows($query_3) == 0){
							// insert cell page position
							mysql_query("INSERT INTO `cell_page_postitions`(`cell_id`, `page_id`, `position`) VALUES('{$r['cell_id']}', '{$res['page_id']}', '{$r['position']}')");
						}
					}
				}
				echo 'Done<br />';
			}
		}
	}
	if(isset($_GET['action']) && $_GET['action'] == 'check_pages_position'){
		$res = array();
		$res['error'] = 0;
		$cell_content_id = !empty($_POST['cell_content_id']) ? strip_tags($_POST['cell_content_id']) : 0;
		$position = !empty($_POST['position']) ? strip_tags($_POST['position']) : 0;
		// check if position is free for each pages
		if(!empty($_POST['pages'])){
			foreach($_POST['pages'] as $p){
				$q = mysql_query("
					SELECT pages.page_name, cell_page_postitions.cell_page_position_id
					FROM cell_page_postitions
					INNER JOIN pages ON pages.page_id = cell_page_postitions.page_id
					WHERE cell_page_postitions.page_id = '{$p}'
					AND cell_page_postitions.position = '{$position}'
					AND cell_page_postitions.cell_id != '{$cell_content_id}'
					LIMIT 1
				");
				if(mysql_num_rows($q)){
					$r = mysql_fetch_array($q);
					$res['error'] = 1;
					$res['error_message'][] = 'Position on page: ' . $r['page_name'] . ' is unavailable!';
				}
			}
		}
		echo json_encode($res);
		die();
	}
	
	
	if(isset($_GET['action']) && $_GET['action'] == 'edit_size'){
		$html = '';
		$page_id = $_POST['page_id'];
		$cell_id = $_POST['cell_id'];
		$size = get_cell_size($page_id, $cell_id);
		$html .= '<div class="edit-cell-wrapper">';
			$html .= '<form method="post" action="' . $site_url . 'ajax.php?action=save_size" name="form_edit_cell_size" id="form_edit_cell_size">';
				$html .= '<div class="edit_cell_title">Edit size</div>';
				$html .= '<p>';
					$html .= "<select name='size' id='size'>";
						$html .= "<option value=''>Small</option>";
						$html .= "<option value='big'";
							if($size == 'big'){
								$html .= " selected='selected'";
							}
						$html .= ">Big</option>";
					$html .= "</select>";
				$html .= '</p>';
				$html .= '<p>';
					$html .= "<input type='submit' name='save_cell_size' id='save_cell_size' value='Save' />";
					$html .= "<input type='button' name='cancel' id='cancel' onclick='hidePopup(); return false;' value='Cancel' />";
				$html .= '</p>';
				$html .= "<input type='hidden' name='cell_id' id='cell_id' value='$cell_id' />";
				$html .= "<input type='hidden' name='page_id' id='page_id' value='$page_id' />";
			$html .= '</form>';
		$html .= '</div>';
		die($html);
	}
	
	if(isset($_GET['action']) && $_GET['action'] == 'save_size'){
		$page_id = $_POST['page_id'];
		$cell_id = $_POST['cell_id'];
		$size = $_POST['size'];

		if(!empty($size)){
			$check_size = mysql_query("SELECT size FROM cell_page_sizes WHERE cell_id = {$cell_id} AND page_id = {$page_id}");
			if(mysql_num_rows($check_size)){
				mysql_query("UPDATE cell_page_sizes SET size = '{$size}' WHERE cell_id = {$cell_id} AND page_id = {$page_id}");
			}
			else{
				mysql_query("INSERT INTO cell_page_sizes(`cell_id`, `page_id`, `size`) VALUES('{$cell_id}', '{$page_id}', '{$size}')");
			}
			header("Location: {$site_url}index.php?page_id=$page_id");
			
		}
		else{
			mysql_query("DELETE FROM cell_page_sizes WHERE cell_id = {$cell_id} AND page_id = {$page_id}");
		}
		header("Location: {$site_url}index.php?page_id=$page_id");
	}
	if(isset($_GET['action']) && $_GET['action'] == 'save_molecule_legend'){
		$page_id = $_POST['page_id'];
		if(!empty($_POST['molecule_legend'])){
			foreach($_POST['molecule_legend'] as $l){
				$l['legend_tooltip'] = htmlspecialchars($l['legend_tooltip'], ENT_QUOTES);
				mysql_query("UPDATE `legend` SET `legend_name` = '{$l['legend_name']}', `legend_tooltip` = '{$l['legend_tooltip']}' WHERE `legend_identifier` = '{$l['legend_identifier']}'");
			}
		}
		header("Location: {$site_url}index.php?page_id={$page_id}");
	}
	
?>