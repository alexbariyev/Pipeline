<?php include('inc/config.php'); // site configuration ?>
<?php include('inc/functions.php'); // site configuration ?>
<?php 
	if(isset($_POST['login'])){
		if(do_login($_POST) == true){
			header("Location: $site_url");
		}
		else {
			$error_message = 'Incorrect username or password!';
		}
	}
	if(isset($_GET['logout'])){
		logout();
		header("Location: $site_url");
	}
?>
<?php include('inc/header.php'); // site header ?>
<?php 
	if(isset($_SESSION['logged'])) {
		$general = get_general_data();
		$full_legend = get_full_legend_data();
		$data = get_page_data(isset($_GET['page_id'])?$_GET['page_id']:'1');
		$attritions = get_page_attritions(isset($_GET['page_id'])?$_GET['page_id']:'1');
		$molecule_legend = get_molecule_legend();
?>
		
		<div id="content">
			<?php include('inc/menu.php'); ?>
			<?php 
				if(empty($_GET) || isset($_GET['page_id'])){
					include('inc/main_cells.php');
				}
				elseif(isset($_GET['pipeline_info'])){
					include('inc/pipeline_info.php');
				}
				elseif(isset($_GET['clinical_trials'])){
					include('inc/clinical_trials.php');
				}
				elseif(isset($_GET['analytics'])){
					include('inc/analytics.php');
				}
				elseif(isset($_GET['full_legend'])){
					include('inc/full_legend.php');
				}
			?>
			<?php include('inc/right.php'); ?>
		</div>
<?php 
	}
	else {
		include('inc/main_not_logged.php'); 
	} 
?>
<?php include('inc/footer.php'); // site footer ?>
