<?php
header ("content-type: text/xml");

	 echo '
	<texts>
		<txt>
			<txt><![CDATA[February 15, 2011]]></txt>
		</txt>
		<txt>
			<txt><![CDATA[October 18, 2011]]></txt>
		</txt>
		<txt>
			<txt><![CDATA[asdasdasd asasd]]></txt>
		</txt>
	</texts>';
?>