<?php
header ("content-type: text/xml");

if($_GET['page'] == 0) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 1) {
	 echo '
	<cells>
	</cells>';
}
if($_GET['page'] == 3) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 5) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 6) {
	 echo '
	<cells>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 7) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 8) {
	 echo '
	<cells>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 9) {
	 echo '
	<cells>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 10) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 11) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 12) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 13) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>39</position>
			<name><![CDATA[Eg5 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>59</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>67</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>71</position>
			<name><![CDATA[bone healing]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>72</position>
			<name><![CDATA[anemia]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[This is a biologic being investigated for its potential in treating cancer-related anemia.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>73</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>74</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>75</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>78</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>82</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>83</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>88</position>
			<name><![CDATA[BACE inhibitor<br>Alzheimer]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>89</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>93</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>98</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 14) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
	</cells>';
}
if($_GET['page'] == 15) {
	 echo '
	<cells>
		<cell>
			<position>3</position>
			<name><![CDATA[Liprotamase <br  > pancreas insuff.]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>4</position>
			<name><![CDATA[Florbetapir <br> ß-amyloid imaging]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>5</position>
			<name><![CDATA[** Linagliptin <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>6</position>
			<name><![CDATA[Arxxant DR]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[A new drug application for ruboxistaurin mesylate as a treatment for diabetic retinopathy was submitted to the U.S. Food and Drug Administration in February 2006. In its approvable letter, the FDA requested additional data. In March 2007, the FDA rejected Lilly&#39;s appeal of the agency&#39;s demand for an additional three-year Phase III trial. Lilly withdrew its application for the approval of ruboxistaurin mesylate in <B>Europe</B>. There is a remote chance that Lilly&#39;s ongoing Phase III trials will be sufficient to answer the FDA&#39;s questions <B>surrounding the pending U.S. application</B>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>7</position>
			<name><![CDATA[NERI <br> depression]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[NERI is a potent and highly selective norepinepherine reuptake inhibitor. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin15"><U>Full Story</U></a> and <a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin16"><U>Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>8</position>
			<name><![CDATA[BAFF antibody<br> RA/lupus]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>9</position>
			<name><![CDATA[Ramucirumbab <br>solid tumors]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-1121B (ramucirumab) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against vascular endothelial growth factors being developed by ImClone. Growth of certain cancers, such as breast cancer, depends on the activation of vascular endothelial growth factor receptors.<BR><BR>IMC-1121B is designed to bind to a specific vascular endothelial growth factor receptor (VEGF) known as VEGFR-2. Studies indicate that IMC-1121B inhibits the growth of human endothelial cells, which are essential to the development and function of blood and lymph vessels. The potential of IMC-1121B to inhibit tumor angiogenesis or blood vessel formation holds great promise as a potential therapeutic for several types of cancer. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-1121B%20(ramucirumab).aspx" target="mwin1"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>10</position>
			<name><![CDATA[Solanezumab<br> Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin34"><U>Click to view the Solanezumab "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>11</position>
			<name><![CDATA[** BI 10773<br>diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[005f97]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>12</position>
			<name><![CDATA[GLP-1Fc <br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s investigational glucagon-like peptide 1 analog, known as GLP-1Fc or LY2189265, is a novel-engineered fusion protein administered subcutaneously once weekly for the treatment of type 2 diabetes. Scientists believe GLP-1Fc lowers blood glucose by enhancing glucose-stimulated insulin secretion from the pancreas. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20GLP-1Fc.aspx" target="mwin4"><U>Full Story</U></a><BR><BR><a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin5"><U>Click to view GLP-1Fc "Promise of the Pipeline" Feature Spotlight </U></a>]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>16</position>
			<name><![CDATA[Enzastaurin <br> DLBCL]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>17</position>
			<name><![CDATA[** Necitumumab <br> NSCLC]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information]]></toolTip>
			<description><![CDATA[Necitumumab (IMC-11F8) is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies against the epidermal growth factor receptor (EGFR) being developed by ImClone.<BR><BR>EGFR is a protein found on the surface of cells to which epidermal growth factor (EGF) binds. When EGF attaches to EGFR, it activates the enzyme tyrosine kinase, which triggers reactions that cause the cells to proliferate. EGFR is found at abnormally high levels on the surface of many types of cancer cells, which may divide excessively in the presence of EGF. Designed to bind to EGFR, necitumumab targets the same receptor as Erbitux® (cetuximab). Unlike necitumumab, Erbitux is a chimeric antibody, part mouse protein and part human protein. Preclinical data indicate that necitumumab’s activity is comparable to or greater than that observed with Erbitux. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Necitumumab_IMC-11F8.aspx " target="mwin40"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>19</position>
			<name><![CDATA[IL-17 antibody<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IL-17 antibody (LY2439821) is a humanized immunoglobulin monoclonal antibody that neutralizes interleukin-17A (IL-17), which is elevated in some chronic autoimmune diseases. IL-17 antibody has promise as an effective therapy for several inflammatory diseases, including rheumatoid arthritis. It is administered by injection. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IL-17_antibody_(LY2439821).aspx" target="mwin6"><U>Story</U></a> and<a href="http://lillynetcollaboration.global.lilly.com/sites/KeyInfo/Pages/Video.aspx" target="mwin6"><U> Video</U></a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>20</position>
			<name><![CDATA[IMC-3G3<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[IMC-3G3 is a fully human monoclonal antibody being investigated as a treatment for cancer. It is one of the antibodies being developed by ImClone, which is part of Lilly oncology.<BR><BR>IMC-3G3 was the first into the clinic of only two known therapeutics that specifically target the platelet derived growth factor receptor alpha (PDGFRa), which is expressed by many types of cancers and is also present in tumor-stroma. Tumors and associated stroma, which is connective tissue, produce PDGF ligands that stimulate the receptor in both tumor and stroma, resulting in tumor growth and production of new blood vessels via autocrine and/or paracrine mechanisms. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_IMC-3G3.aspx" target="mwin19"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>21</position>
			<name><![CDATA[OpRA <br> alcohol depend]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[OpRA II is an orally active pan-selective opioid receptor antagonist (OpRA) being studied for the treatment of alcohol dependence. By blocking activity of the opioid system, OpRA II dampens activation of the brain reward circuitry, allowing the patient greater control to reduce alcohol consumption and cravings. OpRA II has the potential to help patients suffering from alcohol dependence reduce harmful levels of heavy drinking, leading to improved health and functional outcomes. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_NERI.aspx" target="mwin16"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>22</position>
			<name><![CDATA[Tasisulam<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Tasisulam sodium (LY573636) is a small-molecule anticancer compound with a unique, first-in-class mechanism of action. It induces apoptosis or programmed cell death in cancer cells by targeting specific mitochondrial enzymes important for energy production and metabolism.<!-- Mitochondria are often referred to as "cellular power plants" because they generate most of a cell&#39;s supply of chemical energy. In addition, mitochondria are involved in other cell processes, including signaling, cellular differentiation, and cell growth and death.<BR><BR>In the laboratory, tasisulam sodium has exhibited anti-angiogenesis activity. Angiogenesis, the growth of new blood vessels, is part of normal growth, development, and healing but is also required for the rapid growth of malignant tumors. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20-%20Tasisulam%20Sodium%20(2).aspx" target="mwin14"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>24</position>
			<name><![CDATA[agitation in<br>Alzheimer]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>26</position>
			<name><![CDATA[Cixutumumab<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[ImClone&#39;s fully human monoclonal antibody Cixutumumab (IMC-A12) is being investigated as a cancer treatment. Cixutumumab (IMC-A12) selectively blocks the insulin-like growth factor-1 receptor (IGF-1R), preventing insulin-like growth factor (IGF) ligands from binding to and activating the receptor. <!-- This action blocks a signaling pathway that enhances tumor cell proliferation and survival.<BR><BR>The IGF-1R is expressed on almost all cancer cells. Not only does this receptor govern tumor growth, but it also modulates the sensitivity and resistance of tumors to chemotherapy, radiation, hormonal therapies, and targeted therapies, such as, Herceptin® and Erbitux®. -->See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule%20of%20the%20Month%20IMC-A12.aspx" target="mwin2"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>28</position>
			<name><![CDATA[BPH]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>29</position>
			<name><![CDATA[mGlu2/3 pro<br>schizophrenia]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[mGlu2/3 pro drug receptor agonist has the potential to address both the positive and negative symptoms of schizophrenia, with a lessened possible treatment emergent adverse event profile than currently available therapies. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_mGlu23_agonist.aspx" target="mwin16"><U>Full Story</U></a> <a href="http://player.backlight.tv/player/?video_code=kT61NaPI4Ki4fdjfeRSLVw6239EQ90L6239EQ90L" target="mwin16">Click here to view the mGlu2/3 pro drug Promise of the Pipeline Feature Spotlight.</a>]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>31</position>
			<name><![CDATA[CETP<br>atherosclerosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>32</position>
			<name><![CDATA[Survivin ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Y2181308, a survivin antisense oligonucleotide (ASO), was developed specifically to target survivin, a protein that plays a role in cancer cell death, or apoptosis. Survivin is over-expressed in 80 to 90 percent of tumors but is virtually nonexistent in healthy tissue.<!-- Research indicates LY2181308 inhibits the expression of survivin and may reduce the growth of cancer cells. LY2181308 is given as a three-hour infusion in clinical trials, as a loading dose for three consecutive days followed by weekly maintenance doses.<BR><BR>In June, results from a Phase I clinical trial were presented at the annual meeting of the American Society of Clinical Oncology (ASCO). The study&#39;s primary objective was to determine the recommended dose of LY2181308 to be used in Phase II trials. Slides from the presentation, which almost 2,000 people attended, are available on the ASCO website. --> See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Survivin_ASO_LY2181308_.aspx" target="mwin12"><U>Full Story</U></a>]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>33</position>
			<name><![CDATA[JAK-1/JAK-2<br>RA]]></name>
			<bgColor><![CDATA[cdecff]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		<cell>
			<position>34</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>35</position>
			<name><![CDATA[eIF-4E ASO<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Lilly&#39;s elF-4e antisense oligonucleotide (ASO) is a second-generation ASO. ASOs show promise in reducing the expression of genes and proteins involved in human cancer.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>37</position>
			<name><![CDATA[osteoporosis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>38</position>
			<name><![CDATA[Chk-1 inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[When given in combination with chemotherapeutic agents, Chk1 inhibitor prevents tumor cell repair. Chk1 inhibitor is expected to improve the effectiveness of existing therapies, without significantly increasing the side effects of chemotherapy. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Chk1_InhibitorI_LY2603618.aspx" target="mwin12"><U>Full Story</U></a> and <a href="http://link.backlight.tv/lilly/videos/chk--inhibitor-403.html" target="mwin13"><U>Video</U></a>.]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>40</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>42</position>
			<name><![CDATA[erectyle <br>disfunction ]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>44</position>
			<name><![CDATA[IMC-18F1<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. This angiogenesis inhibitor is in Phase I clinical trials for solid tumors. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>45</position>
			<name><![CDATA[** Basal insulin<br> diabetes]]></name>
			<bgColor><![CDATA[cccc00]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Click here for more information.]]></toolTip>
			<description><![CDATA[Basal insulin lispro (BIL) consists of insulin lispro (the active pharmaceutical ingredient in Humalog®) chemically modified by the covalent attachment of a high molecular-weight polyethylene glycol (PEG) polymer. BIL is designed to support a true once-daily dosing regimen in patients with diabetes; however, its time-action profile may enable less frequent dosing regimens. See <a href="http://lillynet.global.lilly.com/sites/LRLCommunications/news/Pages/Molecule_of_the_Month_Basal_insulin_lispro.aspx" target="mwin16"><U>Full Story</U></a><BR><BR><a href="http://link.backlight.tv/lilly/videos/bil-basal-insulin-lispro-273.html" target="mwin16"><U>Click to view the Basal Insulin "Promise of the Pipeline" Feature Spotlight</U></a>.]]></description>
			<overBgColor><![CDATA[797900]]></overBgColor>
		</cell>
		<cell>
			<position>46</position>
			<name><![CDATA[TGF ß antibody<br> CRD]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>49</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>50</position>
			<name><![CDATA[IL-1 ß antibody <br>CV disease]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[e76a2e]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>51</position>
			<name><![CDATA[TGF ß inhibitor<br>cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>52</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>53</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>54</position>
			<name><![CDATA[alcohol <br>dependence]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>55</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>56</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[none]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>57</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>58</position>
			<name><![CDATA[Gem prodrug<br> cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>61</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>62</position>
			<name><![CDATA[obesity]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>63</position>
			<name><![CDATA[osteoarthritis]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>64</position>
			<name><![CDATA[nephropathy]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New chemical entity. Description forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>65</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>69</position>
			<name><![CDATA[depression]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>76</position>
			<name><![CDATA[diabetes]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Biologic Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>77</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>80</position>
			<name><![CDATA[bipolar disorder]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
		<cell>
			<position>84</position>
			<name><![CDATA[cancer]]></name>
			<bgColor><![CDATA[ffffa6]]></bgColor>
			<triangle><![CDATA[00a652]]></triangle>
			<animation>on</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[e76a2e]]></overBgColor>
		</cell>
		<cell>
			<position>85</position>
			<name><![CDATA[migraine prevention]]></name>
			<bgColor><![CDATA[f0bdcc]]></bgColor>
			<triangle><![CDATA[none]]></triangle>
			<animation>off</animation>
			<toolTip><![CDATA[New Chemical Entity. Description Forthcoming.]]></toolTip>
			<description><![CDATA[none]]></description>
			<overBgColor><![CDATA[9e4363]]></overBgColor>
		</cell>
	</cells>';
}
?>