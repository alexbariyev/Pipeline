<?php
header ("content-type: text/xml");

if($_GET['page'] == 0) {
	 echo '
	<others>
		<attrition>
		<cell>
			<name><![CDATA[agitation in<br>Alzheimer&#39;s]]></name>
			<bgColor><![CDATA[238dce]]></bgColor>
			<triangle><![CDATA[238dce]]></triangle>
			<toolTip><![CDATA[238dce]]></toolTip>
			<description><![CDATA[238dce]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 1) {
	 echo '
	<others>
		<attrition>
		<cell>
			<name><![CDATA[agitation in<br>Alzheimer&#39;s]]></name>
			<bgColor><![CDATA[238dce]]></bgColor>
			<triangle><![CDATA[238dce]]></triangle>
			<toolTip><![CDATA[238dce]]></toolTip>
			<description><![CDATA[238dce]]></description>
			<overBgColor><![CDATA[238dce]]></overBgColor>
		</cell>
		</attrition>
		<pageDescription><![CDATA[Here are a few important instructions for using this site:
<ul>
<li>Click <B>Home</B> to view the full Lilly Pipeline.</li><li>Click <B>Views</B> to look at the Pipeline by Business Area or by Phase.</li><li>Click <B>Molecule Naming Convention</B> to understand how different molecules are named.</li><li>Click <B>Handoffs</B> to understand the handoff between research and the businesses.</li><li>Within each view, click directly on a molecule to learn more about it.</li><li>Click on the <B>"For more information..."</B> links throughout the site to learn 
about specific diseases and phases.</li>
</ul><br/>
<I>Important Note:</I> Lilly&#39;s clinical development pipeline includes only new molecular entities (potential, unique medicines). Included is the lead indication for each molecule; excluded are earlier indications for pipeline molecules and new indications or line extensions of currently-marketed products.]]></pageDescription>
		<legend><![CDATA[]]></legend>
	</others>';
}
if($_GET['page'] == 3) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[When naming a molecule in the pipeline, <B>timing</B> and <B>confidentiality</B> are the two key factors.<BR><BR>Lilly cannot submit for a generic name (nonproprietary name) until it has submitted an Investigational New Drug Application (IND) to regulatory authorities. Typically, generic name development begins after First Human Dose (FHD) and before First Efficacy Dose (FED), meaning late Phase I or early Phase II. Trademarks are developed in late Phase II or early Phase III. It may take up to three years to get name approval from the U.S. Adopted Names Council (USAN) and the World Health Assembly&#39;s International Nomenclature Committee (INN) and at least two years to minimize trademark-naming risk.]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 5) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[]]></legend>
	</others>';
}
if($_GET['page'] == 6) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 7) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[The <b>Emerging Markets</b> business area will commercialize all Lilly approved products in the emerging markets which encompass all geographies EXCEPT Australia, Canada, Europe, Japan, New Zealand, and the United States.]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 8) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 9) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[]]></legend>
	</others>';
}
if($_GET['page'] == 10) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[]]></legend>
	</others>';
}
if($_GET['page'] == 11) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 12) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 13) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[]]></pageDescription>
		<legend><![CDATA[]]></legend>
	</others>';
}
if($_GET['page'] == 14) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[The handoff is a new milestone that was created as part of the new operating model. Ownership of molecules will be handed off from research to the businesses which will be run like separate companies within Lilly to create a clearer line of sight to the customer, clarify accountability and authority, and speed decision making.<BR><BR><B>First Human Dose (FHD) marks the transfer of molecule ownership of Cancer and Autoimmune molecules to their respective business areas.]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
if($_GET['page'] == 15) {
	 echo '
	<others>
		<attrition>
		</attrition>
		<pageDescription><![CDATA[The handoff is a new milestone that was created as part of the new operating model. Ownership of molecules will be handed off from research to the businesses which will be run like separate companies within Lilly to create a clearer line of sight to the customer, clarify accountability and authority, and speed decision making.<BR><BR><B>Proof of Concept (POC) or Commercial decision (CD) marks the transfer of molecule ownership for all molecules, excluding Autoimmunity and Oncology, to their respective business areas, depending on the specific asset under consideration.</B>]]></pageDescription>
		<legend><![CDATA[* sold to a third-party<br>** Commercial Collaboration]]></legend>
	</others>';
}
?>