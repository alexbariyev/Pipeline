<?php include('inc/config.php'); // site configuration ?>
<?php include('inc/functions.php'); // site configuration ?>
<?php
	if(isset($_SESSION['logged'])) {
		// getting general information of lilly project
		$sql = "SELECT name,value
				FROM general_information";
		
		$result = mysql_query($sql);
		$general_info = array();
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
					$general_info[$res['name']] = $res['value'];
			}
		}
		// getting page content and id
		$sql = "SELECT page_id, page_description, page_attrition_description, page_type
							FROM pages WHERE page_id != '12'
							ORDER BY page_id ASC";
		
		$result = mysql_query($sql);
		$molecule_legend = get_molecule_legend();
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$size = ($res['page_id'] == 1 || $res['page_id'] == 13 || $res['page_type'] == 'm') ? '' : 'big';
				$size_nr = ($res['page_id'] == 1 || $res['page_id'] == 13 || $res['page_type'] == 'm') ? '6' : '3';
				$stringData = "";
				if($res['page_id'] != 1){
					$myFile = $files_path . ($res['page_id']) . '.html';
				}
				else{
					$myFile = $files_path . 'index.html';
				}
				$fh = fopen($myFile, 'w+') or die("can't open file");
					$a_home = '';
					switch($res['page_id']){
						case 1:
							$a_home = 'active';
							break;
					}
					// adding content to page
					$stringData = "
						<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">
						<html>
						<head>
							<title>Lilly</title>
							<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
							<link rel=\"stylesheet\" type=\"text/css\" href=\"fonts/stylesheet.css\">
							<link rel=\"stylesheet\" type=\"text/css\" href=\"jquery.qtip.css\">
							<link rel=\"stylesheet\" type=\"text/css\" href=\"site.css\">
							<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js\" type=\"text/javascript\"></script>
							<script src=\"jquery.qtip-1.0.0-rc3-dm.js\" type=\"text/javascript\"></script>
							<script src=\"jquery.bpopup-0.5.1.min.js\" type=\"text/javascript\"></script>
							<script src=\"site.js\" type=\"text/javascript\"></script>
							<script type=\"text/javascript\">
								$(document).ready(function(){
									// Match all <A/> links with a title tag and use it as the content (default).
									$('a.tooltip[title]').qtip({
										position: {
											adjust: { x: 5, y: 10 },
											corner: {
												target: 'topRight',
												tooltip: 'topLeft'
											}
										},
										style: {
											width: 150,
											name: 'dark',
											tip: {
												corner: 'topLeft',
												color: '#979797',
												size: {
													x: 9,
													y : 10
												}
											}
										}
									});
									$('a.bigtooltip[title]').qtip({
										position: {
											adjust: { x: 5, y: 10 },
											corner: {
												target: 'topRight',
												tooltip: 'topLeft'
											}
										},
										style: {
											width: 236,
											name: 'dark',
											tip: {
												corner: 'topLeft',
												color: '#979797',
												size: {
													x: 9,
													y : 10
												}
											}
										}
									});
									$('a.bigtooltip_left[title]').qtip({
										position: {
											adjust: { x: 0, y: 10 },
											corner: {
												target: 'topLeft',
												tooltip: 'topRight'
											}
										},
										style: {
											width: 580,
											name: 'dark',
											tip: {
												corner: 'topRight',
												color: '#979797',
												size: {
													x: 9,
													y : 10
												}
											}
										}
									});
									
									/*
									$('a.tooltip_under[title]').qtip({
										position: {
											corner: {
												target: 'bottomCenter',
												tooltip: 'bottomCenter'
											}
										},
										style: {
											width: 96,
											name: 'gray'
										}
									});
									
									$('a.bigtooltip_under[title]').qtip({
										position: {
											corner: {
												target: 'bottomCenter',
												tooltip: 'bottomCenter'
											}
										},
										style: {
											width: 191,
											name: 'gray'
										}
									});
									$('.molecule-container li a label').each(function(){
										if($(this).html().length < 20){
											$(this).parent().css('padding-top', '3px');
											$(this).parent().css('line-height', '32px');
											$(this).parent().css('height', '32px');
										}
									});
									*/
									$('a.bigtooltip_under').hover(function(){
											$(this).addClass('hovered');
										},
										function(){
											$(this).removeClass('hovered');
										}
									);
									$('a.tooltip_under').hover(function(){
											$(this).addClass('hovered');
										},
										function(){
											$(this).removeClass('hovered');
										}
									);
								});
							</script>
						</head>
						<body>
						<div id=\"browser_notice\">
							This website is optimized for visualization with Firefox and Internet Explorer (8 or 9)
						</div>
							<div id=\"container\">
								<div id=\"header\">
									<img src=\"./img/header.png\" alt=\"Lilly - Development Pipeline\" />
								</div>
								<div id=\"content\">
									<div id=\"content-left\">
										
										<h1 class=\"DINBold\"><a href=\"index.html\">Pipeline Overview</a></h1>
				";
								$stringData .= "
									<div class=\"menu\">
										<h2 class=\"DINBold\">View by Therapeutic Area</h2>
										<ul>
								";
									$sql = "SELECT page_id, page_name
										FROM pages WHERE page_id != '1' AND page_type = 't'
										ORDER BY page_name ASC";
					
									$result_pages = mysql_query($sql);
									if(mysql_num_rows($result_pages)){
										while($p = mysql_fetch_array($result_pages)){
											$class = '';
											if($res['page_id'] == $p['page_id']){
												$class = 'active';
											}
											$stringData .= "<li><a href=\"{$p['page_id']}.html\" class=\"{$class}\" title=\"{$p['page_name']}\">{$p['page_name']}</a></li>";
										}
									}
								$stringData .= "
										</ul>
								";
								$stringData .= "
										<h2 class=\"DINBold\">View by Molecule Type</h2>
										<ul>
								";
									$sql = "SELECT page_id, page_name
										FROM pages WHERE page_id != '1' AND page_type = 'm'
										ORDER BY page_position ASC";

									$result_pages = mysql_query($sql);
									if(mysql_num_rows($result_pages)){
										while($p = mysql_fetch_array($result_pages)){
											$class = '';
											if($res['page_id'] == $p['page_id']){
												$class = 'active';
											}
											$stringData .= "<li><a href=\"{$p['page_id']}.html\" class=\"{$class}\" title=\"{$p['page_name']}\">{$p['page_name']}</a></li>";
										}
									}
								$stringData .= "
										</ul>
									</div>
								";
								$stringData .= "
										<p>
											<a>Pipeline movement since {$general_info['since']}</a>
										</p>
										<p>
											<a>Pipeline data through<br />{$general_info['data_last_update']}</a>
										</p>
								";
				/*
				$stringData .= "
										<p>
											For information on<br /> ongoing clinical<br /> trials, please<br />
											<a id=\"clinical-trials\" href=\"\" title=\"Click here\">click here</a>
											<div class=\"content-popup-big\" id=\"clinical-trials-content\">
												<div class=\"pipeline-description\">
													{$general_info['clinical_trials']}
												</div>
												<a class=\"bClose\">&nbsp;</a>
											</div>
											<script type=\"text/javascript\">
												$(\"#clinical-trials\").bind('click', function(){
													$(\"#clinical-trials-content\").bPopup();
													return false
												});
											</script>
										</p>";
				*/
				$stringData .= "
										
									</div>
									<div id=\"content-center\">";
										// getting cells for this page
										$data = get_page_data($res['page_id']);
										
										
										// Regulatory Review
										$stringData .= "
											<h1 class=\"big_h1\">CLINICAL DEVELOPMENT <span>PIPELINE</span></h1>
											<div class=\"cells-container\">
												<div class=\"cells-container-inner\">
													<h1 class=\"toggle active\"><label class=\"exp_open\"></label><span>{$general_info['title_1']}</span></h1>
													<ul class=\"molecule-container\">
										";
														for($i=1; $i<=6; $i++) {
															$stringData .= get_export_data($data[$i], $i, $size, $general_info['title_1']);
														}
										$stringData .= "
													</ul>
												</div>
											</div>
										";
										// Select New Indication or Line Extension (NILEX)
										if($res['page_id'] == 1){
											$stringData .= "
												<div class=\"cells-container\">
													<div class=\"cells-container-inner\">
														<h1 class=\"toggle\"><label class=\"exp\"></label><span>{$general_info['title_2']}</span></h1>
														<ul class=\"molecule-container\" style=\"display: none;\">
											";
										}
										else{
											$stringData .= "
												<div class=\"cells-container\">
													<div class=\"cells-container-inner\">
														<h1 class=\"toggle\"><label class=\"exp\"></label><span>{$general_info['title_2']}</span></h1>
														<ul class=\"molecule-container\" style=\"display: none;\">
											";
										}
															for($i=7; $i<=36; $i++) {
																$stringData .= get_export_data($data[$i], $i, $size, $general_info['title_2']);
															}
											$stringData .= "
														</ul>
													</div>
											";
											$stringData .="
												</div>
											";
										
										
										// Phase III
										$stringData .= "
											<div class=\"cells-container\">
												<div class=\"cells-container-inner\">
													<h1 class=\"toggle active\"><label class=\"exp_open\"></label><span>{$general_info['title_3']}</span></h1>
													<ul class=\"molecule-container\">
										";
														for($i=37; $i<=54; $i++) {
															$stringData .= get_export_data($data[$i], $i, $size, $general_info['title_3']);
														}
										$stringData .= "
													</ul>
												</div>
											</div>
										";
										
										// Phase II
										$stringData .= "
											<div class=\"cells-container\">
												<div class=\"cells-container-inner\">
													<h1 class=\"toggle active\"><label class=\"exp_open\"></label><span>{$general_info['title_4']}</span></h1>
													<ul class=\"molecule-container\">
										";
														for($i=55; $i<=90; $i++) {
															$stringData .= get_export_data($data[$i], $i, $size, $general_info['title_4']);
														}
										$stringData .= "
													</ul>
												</div>
											</div>
										";
										
										// Phase I
										if($res['page_id'] != 1){
											$stringData .= "
												<div class=\"cells-container\">
													<div class=\"cells-container-inner\">
													<h1 class=\"toggle active\"><label class=\"exp_open\"></label><span>{$general_info['title_5']}</span></h1>
													<ul class=\"molecule-container\">
											";
										}
										else{
											$stringData .= "
												<div class=\"cells-container\">
													<div class=\"cells-container-inner\">
													<h1 class=\"toggle active\"><label class=\"exp_open\"></label><span>{$general_info['title_5']}</span></h1>
													<ul class=\"molecule-container\">
											";
										}
															for($i=91; $i<=126; $i++) {
																$stringData .= get_export_data($data[$i], $i, $size, $general_info['title_5']);
															}
											$stringData .= "
														</ul>
													</div>
											";
											$stringData .="
												</div>
											";
										
									$stringData .= "
										<div class=\"disclaimer\">{$general_info['pipeline_info']}</div>
										<p class=\"footer\">
											Property of Eli Lilly and Company.
										</p>
									</div>
									<div id=\"content-right\">
									";
									
									$stringData .= "
										<div class=\"molecule-info2\">
										<h1>Legend</h1>
									";
											if(!empty($molecule_legend)){
												foreach($molecule_legend as $m){
													$stringData .= "<a href=\"full_legend.html\"><div class=\"molecule-data\">";
														$stringData .= "<img class=\"fl\" align=\"absmiddle\" src=\"./img/{$m['legend_identifier']}.png\" alt=\"\" />";
														$stringData .= "<div class=\"molecule-text\">{$m['legend_name']}</div>";
													$stringData .= "</div></a>";
												}
											}
									$stringData .= "
											<div class=\"molecule-data\">
												{$res['page_attrition_description']}
											</div>
										</div>
									";
									
										$sql_attrition = sprintf("SELECT attrition_content_id, attrition_pages.page_id, name, bgColor, triangle, toolTip, box_title, description, overBgColor
												FROM attritions_content INNER JOIN attrition_pages ON attritions_content.attrition_content_id = attrition_pages.attrition_id
												WHERE attrition_pages.page_id = %d
												ORDER BY attritions_content.attrition_content_id ASC",
												$res['page_id']);
										$result_attrition = mysql_query($sql_attrition);
										if(mysql_num_rows($result_attrition)){
											$stringData .= "<ul class=\"molecule-info\">";
											while($res_attrition = mysql_fetch_array($result_attrition)){
												$stringData .= "
													<li>
														<span class=\"{$res_attrition['bgColor']}_cell\">{$res_attrition['name']}</span>
													</li>
												";
											}
											$stringData .= "</ul>";
										}
									$stringData .= "
										<div id=\"full_legend_link\">
											For more information about Lilly's interactive pipeline website, <a href=\"full_legend.html\">click here</a>
										</div>
									</div>
								</div>
								<div id=\"footer\">
								</div>
							</div>
					";
						$stringData .= "
								<script type=\"text/javascript\">
									$(window).load(function(){
										var cCenterHeight = $('#content-center').height();
										var cLeftHeight = $('#content-left').height();
										var paddingTop = cCenterHeight-cLeftHeight-10;
										if(paddingTop > 0){
											//$('.footer').css('padding-top', parseInt(paddingTop)+'px');
										}
										$('.molecule-container').each(function(){
											
											if(!$(this).has('li').length){
												$(this).css('padding', '0');
											}
											
											$(this).find('a.big').each(function(){
												
												var a_height = $(this).height();
												
												var label_height = $(this).find('label').height();
												if(label_height != 0){
													$(this).find('label').css('padding-top', parseInt(((a_height-label_height)/2)-5));
												}
												else{
													$(this).find('label').css('padding-top', 12);
												}
											});
											
										});
										//Set default open/close settings
										//$('.molecule-container').hide(); //Hide/close all containers
										//$('.cells-container-inner h1:last').addClass('active').next().hide(); 

									});
								</script>
						";
						
						$class = 'toggle';
						
						$stringData .= "
							<script type=\"text/javascript\">
								$(document).ready(function(){
									// align text in center
									$('.molecule-info2 .molecule-data').each(function(){
										var molecule_text_height = $(this).children('.molecule-text').height();
										if(molecule_text_height < 23){
											$(this).children('.molecule-text').css('padding-top', (23-molecule_text_height)/2);
										}
									});
									//On Click
									$('.cells-container-inner h1.{$class}').click(function(){
											if($(this).hasClass('active')){
												$(this).toggleClass('active').next().slideUp(); //Add \"active\" state to clicked trigger and slide down the immediate next container
												$(this).children('label').toggleClass('exp_open');
											}else{
												$(this).toggleClass('active').next().slideDown(); //Add \"active\" state to clicked trigger and slide down the immediate next container
												$(this).children('label').toggleClass('exp_open');
											}
										return false; //Prevent the browser jump to the link anchor
									});
									$('.molecule-container').each(function(){
										var i = 0;
										var j = 0;
										var a = new Array({$size_nr});
										$(this).find('li').each(function(){
											if($(this).hasClass('empty')){
												a[i] = $(this);
												j++;
											}
											i++;
											if(j == {$size_nr}){
												for(var k = 0;k < {$size_nr};k++){
													a[k].remove();
												}
											}
											if(i == {$size_nr}){
												i = 0;
												j = 0;
											}
										});
									});
								});
								
							</script>
						";
					$stringData .="{$general_info['analytics']}
						</body>
						</html>
					";
				fwrite($fh, $stringData);
				fclose($fh);
			}
		}
		
		$legend_sql = "SELECT * FROM full_legend";
		$legend_result = mysql_query($legend_sql);
		
		$myFile = $files_path . 'full_legend.html';
		$fh = fopen($myFile, 'w+') or die("can't open file");
					// adding content to page
					$stringData = "
						<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">
						<html>
						<head>
							<title>Lilly</title>
							<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
							<link rel=\"stylesheet\" type=\"text/css\" href=\"fonts/stylesheet.css\">
							<link rel=\"stylesheet\" type=\"text/css\" href=\"jquery.qtip.css\">
							<link rel=\"stylesheet\" type=\"text/css\" href=\"site.css\">
							<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js\" type=\"text/javascript\"></script>
							<script src=\"jquery.qtip-1.0.0-rc3-dm.js\" type=\"text/javascript\"></script>
							<script src=\"jquery.bpopup-0.5.1.min.js\" type=\"text/javascript\"></script>
							<script src=\"site.js\" type=\"text/javascript\"></script>
							<script type=\"text/javascript\">
								$(document).ready(function(){
									// Match all <A/> links with a title tag and use it as the content (default).
									$('a.tooltip[title]').qtip({
										position: {
											adjust: { x: 5, y: 10 },
											corner: {
												target: 'topRight',
												tooltip: 'topLeft'
											}
										},
										style: {
											width: 150,
											name: 'dark',
											tip: {
												corner: 'topLeft',
												color: '#979797',
												size: {
													x: 9,
													y : 10
												}
											}
										}
									});
									$('a.bigtooltip[title]').qtip({
										position: {
											adjust: { x: 5, y: 10 },
											corner: {
												target: 'topRight',
												tooltip: 'topLeft'
											}
										},
										style: {
											width: 236,
											name: 'dark',
											tip: {
												corner: 'topLeft',
												color: '#979797',
												size: {
													x: 9,
													y : 10
												}
											}
										}
									});
									$('a.bigtooltip_left[title]').qtip({
										position: {
											adjust: { x: 0, y: 10 },
											corner: {
												target: 'topLeft',
												tooltip: 'topRight'
											}
										},
										style: {
											width: 580,
											name: 'dark',
											tip: {
												corner: 'topRight',
												color: '#979797',
												size: {
													x: 9,
													y : 10
												}
											}
										}
									});
									
									/*
									$('a.tooltip_under[title]').qtip({
										position: {
											corner: {
												target: 'bottomCenter',
												tooltip: 'topCenter'
											}
										},
										style: {
											width: 96,
											name: 'gray'
										}
									});
									
									$('a.bigtooltip_under[title]').qtip({
										position: {
											corner: {
												target: 'bottomCenter',
												tooltip: 'topCenter'
											}
										},
										style: {
											width: 191,
											name: 'gray'
										}
									});
									$('.molecule-container li a label').each(function(){
										if($(this).html().length < 20){
											$(this).parent().css('padding-top', '3px');
											$(this).parent().css('line-height', '32px');
											$(this).parent().css('height', '32px');
										}
									});
									*/
								});
							</script>
						</head>
						<body>
						<div id=\"browser_notice\">
							This website is optimized for visualization with Firefox and Internet Explorer (8 or 9)
						</div>
							<div id=\"container\">
								<div id=\"header\">
									<img src=\"./img/header.png\" alt=\"Lilly - Development Pipeline\" />
								</div>
								<div id=\"content\">
									<div id=\"content-left\">
										
										<h1 class=\"DINBold\"><a href=\"index.html\">Pipeline Overview</a></h1>
				";
								$stringData .= "
									<div class=\"menu\">
										<h2 class=\"DINBold\">View by Therapeutic Area</h2>
										<ul>
								";
									$sql = "SELECT page_id, page_name
										FROM pages WHERE page_id != '1' AND page_id != '12' AND page_type = 't'
										ORDER BY page_name ASC";
					
									$result_pages = mysql_query($sql);
									if(mysql_num_rows($result_pages)){
										while($p = mysql_fetch_array($result_pages)){
											$class = '';
											if($res['page_id'] == $p['page_id']){
												$class = 'active';
											}
											$stringData .= "<li><a href=\"{$p['page_id']}.html\" class=\"{$class}\" title=\"{$p['page_name']}\">{$p['page_name']}</a></li>";
										}
									}
								$stringData .= "
										</ul>
								";
								$stringData .= "
										<h2 class=\"DINBold\">View by Molecule Type</h2>
										<ul>
								";
									$sql = "SELECT page_id, page_name
										FROM pages WHERE page_id != '1' AND page_id != '12' AND page_type = 'm'
										ORDER BY page_position ASC";

									$result_pages = mysql_query($sql);
									if(mysql_num_rows($result_pages)){
										while($p = mysql_fetch_array($result_pages)){
											$class = '';
											if($res['page_id'] == $p['page_id']){
												$class = 'active';
											}
											$stringData .= "<li><a href=\"{$p['page_id']}.html\" class=\"{$class}\" title=\"{$p['page_name']}\">{$p['page_name']}</a></li>";
										}
									}
								$stringData .= "
										</ul>
									</div>
								";
								$stringData .= "
										<p>
											<a class=\"bigtooltip\" title=\"Date the pipeline website was last updated.\">Pipeline movement since {$general_info['since']}</a>
										</p>
										<p>
											<a class=\"bigtooltip\" title=\"Information on the website is current as of this date. Changes to clinical development programs after this date are not reflected on the site.\">Pipeline data through<br />{$general_info['data_last_update']}</a>
										</p>
								";
				/*
				$stringData .= "
										<p>
											For information on<br /> ongoing clinical<br /> trials, please<br />
											<a id=\"clinical-trials\" href=\"\" title=\"Click here\">click here</a>
											<div class=\"content-popup-big\" id=\"clinical-trials-content\">
												<div class=\"pipeline-description\">
													{$general_info['clinical_trials']}
												</div>
												<a class=\"bClose\">&nbsp;</a>
											</div>
											<script type=\"text/javascript\">
												$(\"#clinical-trials\").bind('click', function(){
													$(\"#clinical-trials-content\").bPopup();
													return false
												});
											</script>
										</p>";
				*/
				$stringData .= "
										
									</div>
									<div id=\"content-center-legend\">";
										// getting cells for this page
										$data = get_full_legend_data();
										
										
										// Regulatory Review
										$stringData .= "
											<h1>UNDERSTANDING LILLY'S CLINICAL DEVELOPMENT <span>PIPELINE</span> WEBSITE</h1>
											<div id=\"top_p\">{$data['top_p']}</div>
											<div id=\"abbrev\"><h2><label class=\"exp\"></label><span>Abbreviations<span></h2><div style=\"display: none;\" class=\"legend-inner-content\">{$data['abbrev']}</div></div>
											<div id=\"faq\"><h2><label class=\"exp\"></label><span>Frequently Asked Questions</span></h2><div style=\"display: none;\" class=\"legend-inner-content\">{$data['faq']}</div></div>
										";
										
									$stringData .= "
										<div class=\"disclaimer\">{$general_info['pipeline_info']}</div>
										<p class=\"footer\">
											Property of Eli Lilly and Company.
										</p>
									</div>
									<div id=\"content-right\">
									";
									
									$stringData .= "
										<div class=\"molecule-info2\">
										<h1>Legend</h1>
									";
											if(!empty($molecule_legend)){
												foreach($molecule_legend as $m){
													$stringData .= "<div class=\"molecule-data\">";
														$stringData .= "<img class=\"fl\" align=\"absmiddle\" src=\"./img/{$m['legend_identifier']}.png\" alt=\"\" />";
														$stringData .= "<div class=\"molecule-text\"><a class=\"bigtooltip_left\" title=\"{$m['legend_tooltip']}\">{$m['legend_name']}</a></div>";
													$stringData .= "</div>";
												}
											}
									$stringData .= "
											<div class=\"molecule-data\">
												{$data['description']}
											</div>
										</div>
									";
									
										$sql_attrition = sprintf("SELECT attrition_content_id, attrition_pages.page_id, name, bgColor, triangle, toolTip, box_title, description, overBgColor
												FROM attritions_content INNER JOIN attrition_pages ON attritions_content.attrition_content_id = attrition_pages.attrition_id
												WHERE attrition_pages.page_id = 1
												ORDER BY attritions_content.attrition_content_id ASC",
												1);
										$result_attrition = mysql_query($sql_attrition);
										if(mysql_num_rows($result_attrition)){
											$stringData .= "<ul class=\"molecule-info\">";
											while($res_attrition = mysql_fetch_array($result_attrition)){
												$stringData .= "
													<li>
														<span class=\"{$res_attrition['bgColor']}_cell\">{$res_attrition['name']}</span>
													</li>
												";
											}
											$stringData .= "</ul>";
										}
									$stringData .= "
										<div id=\"full_legend_link\" class=\"active\">
											For more information about Lilly's interactive pipeline website, <a href=\"full_legend.html\">click here</a>
										</div>
									</div>
								</div>
								<div id=\"footer\">
								</div>
							</div>
					";
						$stringData .= "
								<script type=\"text/javascript\">
									$(window).load(function(){
										var cCenterHeight = $('#content-center').height();
										var cLeftHeight = $('#content-left').height();
										var paddingTop = cCenterHeight-cLeftHeight-10;
										if(paddingTop > 0){
											//$('.footer').css('padding-top', parseInt(paddingTop)+'px');
										}
										$('.molecule-container').each(function(){
											
											if(!$(this).has('li').length){
												$(this).css('padding', '0');
											}
											
											$(this).find('a.big').each(function(){
												
												var a_height = $(this).height();
												
												var label_height = $(this).find('label').height();
												if(label_height != 0){
													$(this).find('label').css('padding-top', parseInt(((a_height-label_height)/2)-5));
												}
												else{
													$(this).find('label').css('padding-top', 12);
												}
											});
											
										});
										//Set default open/close settings
										//$('.molecule-container').hide(); //Hide/close all containers
										//$('.cells-container-inner h1:last').addClass('active').next().hide(); 

									});
								</script>
								<script type=\"text/javascript\">
									$(document).ready(function(){
										$('.answer').parent().hide();
										$('#faq h2').toggleClass('active').next().slideDown(); //Add 'active' state to clicked trigger and slide down the immediate next container
										$('#faq h2').children('label').toggleClass('exp_open');
										$('span.question').first().parent('p').toggleClass('active');
										$('span.question').first().parent('p').next('p').css('display', 'block');
										//On Click
										$('#abbrev h2, #faq h2').click(function(){
												if($(this).hasClass('active')){
													$(this).toggleClass('active').next().slideUp(); //Add 'active' state to clicked trigger and slide down the immediate next container
													$(this).children('label').toggleClass('exp_open');
												}else{
													$(this).toggleClass('active').next().slideDown(); //Add 'active' state to clicked trigger and slide down the immediate next container
													$(this).children('label').toggleClass('exp_open');
												}
											return false; //Prevent the browser jump to the link anchor
										});
										
										$('.question').css('cursor', 'pointer');
										$('span.question').click(function(){
											var question = $(this);
											$('.answer').parent().each(function(){
												if($(this).prev('p').children('span.question').html() != question.html()){
													$(this).hide();
													$(this).prev('p').removeClass('active');
												}
											});
											if(question.parent().hasClass('active')){
												question.parent().nextAll().find('span.answer').eq(0).parent().hide();
												question.parent().removeClass('active');
											}
											else{
												question.parent().nextAll().find('span.answer').eq(0).parent().show();
												question.parent().addClass('active');
											}
											
										});
									});
								</script>
						";
						
					$stringData .="{$general_info['analytics']}
						</body>
						</html>
					";
				fwrite($fh, $stringData);
				fclose($fh);
		
		
		
		
		echo 'export done!';
	}
	else{
		header("Location: $site_url");
	}
?>
