<?php include('inc/config.php'); // site configuration ?>
<?php include('inc/functions.php'); // site configuration ?>
<?php
	$zip = new ZipArchive;
	$file = 'lilly_files_html.zip';
	$filename = $files_path . $file;
	if ($zip->open($filename, ZIPARCHIVE::CREATE)!==TRUE) {
		exit("cannot open <$filename>\n");
	}
	
	$fonts_dir = $dir_path . 'fonts/';
	$img_dir = $dir_path . 'img/';
	$backgrounds_dir = $dir_path . 'img/backgrounds/';
	
	$zip->addEmptyDir('fonts');
	$zip->addEmptyDir('img');
	$zip->addEmptyDir('img/backgrounds');
	
	$files  = scandir($fonts_dir);
	foreach($files as $f){
		if($f != '.' && $f != '..'){
			$zip->addFile($fonts_dir . $f, 'fonts/' . $f);
		}
	}
	
	$files  = scandir($img_dir);
	foreach($files as $f){
		if($f != '.' && $f != '..' && $f != 'backgrounds'){
			$zip->addFile($img_dir . $f, 'img/' . $f);
		}
	}
	
	$files  = scandir($backgrounds_dir);
	foreach($files as $f){
		if($f != '.' && $f != '..'){
			$zip->addFile($backgrounds_dir . $f, 'img/backgrounds/' . $f);
		}
	}
	
	$files  = scandir($dir_path);
	foreach($files as $f){
		if($f != '.' && $f != '..' && $f != 'admin' && $f != 'img' && $f != 'fonts' && $f != '.htaccess' && $f != '.htpasswd'){
			$zip->addFile($dir_path . $f, $f);
		}
	}

	$zip->close();
	
	header("Content-type: application/force-download");
	header('Content-Disposition: inline; filename="' . $filename . '"');
	header("Content-Transfer-Encoding: Binary");
	header("Content-length: ".filesize($filename));
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename="' . $file . '"');
	readfile("$filename"); 
	
	unlink($filename);
?>
