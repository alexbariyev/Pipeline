// new addition 07.03.2013
function init_tinymce(element_class){
	$('.' + element_class).tinymce({
		// Location of TinyMCE script
		script_url : siteURL + 'js/tiny_mce/tiny_mce.js',
		style_formats : [
			{title : 'Question', inline : 'span', classes : 'question'},
			{title : 'Answer', inline : 'span', classes : 'answer'}
		],

		// General options
		theme : "advanced",
		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
		/*
		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,
		*/
		// General options
		theme : "advanced",
		mode: "exact",
		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
		elements : "content",
		
		// theme options
		theme_advanced_toolbar_location : "top",
		theme_advanced_buttons1 : "formatselect, styleselect, bold,italic,underline,separator,justifyleft,justifycenter,justifyright,justifyfull,separator,outdent,indent,separator,link,unlink, undo,redo,code,forecolor",
		theme_advanced_buttons2 : "",
		theme_advanced_buttons3 : "",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,
		forced_root_block : false,
		force_br_newlines : true,
		force_p_newlines : false

		// Example content CSS (should be your site CSS)
		//content_css : "css/content.css",
	});
}

function toggle_menu(elem){
	$('#'+elem).toggle();
}
function showCellActions(theDiv) {
	$(theDiv).find('a.cell-ops').css('display', 'block');
	$(theDiv).addClass('cell-hover');
}

function hideCellActions(theDiv) {
	$(theDiv).find('a.cell-ops').css('display', 'none');
	$(theDiv).removeClass('cell-hover');
}

function showPopup(popupContent, position) {
	$('#lightbox-bg').css('height', $('#container').height());
	$('#lightbox-bg').fadeIn('fast', function() {
		//$('#popup-window').html(popupContent);
		document.getElementById('popup-window').innerHTML = popupContent;
		repositionPopup(position);
		$('#popup-window').fadeIn('fast');
		// load tinyMce for news_box
		init_tinymce('tinyMce');
		$('#lightbox-bg').css('height', $('#container').height());
	});
}

function repositionPopup(position) {
	if (typeof(position) == 'undefined') {
		position = {
			top: false,
			left: false
		};
	}
	else {
		if (typeof(position.top) == 'undefined') {
			position.top = false;
		}
		if (typeof(position.left) == 'undefined') {
			position.left = false;
		}
	}
	
	var top = ($(window).height() - $('#popup-window').height()) / 2;
	var left = ($(window).width() - $('#popup-window').width()) / 2;
	if (position.top !== false) {
		top = position.top;
	}
	if (position.left !== false) {
		left = position.left;
	}
	$('#popup-window').css('top', $(window).scrollTop() + top).css('left', left);
}

function hidePopup() {
	$('#popup-window').fadeOut('fast', function() {
		$('#lightbox-bg').fadeOut('fast');
	})
}

function editCellContent(page_id, position, cell_content_id, phase) {
	$.ajax({
		type: 'POST',
		url: siteURL + 'ajax.php?action=edit',
		data: 'page_id=' + encodeURIComponent(page_id) + '&position=' + encodeURIComponent(position) + '&cell_content_id=' + encodeURIComponent(cell_content_id)+ '&phase=' + encodeURIComponent(phase),
		processData: false,
		success: function(data) {
			showPopup(data, { top: 50 });
		},
		cache: false
	});

}

function deleteCellContent(cell_content_id){
	if(confirm('Are you sure you whant to delete cell content?')){
		$.ajax({
			type: 'POST',
			url: siteURL + 'ajax.php?action=delete_cell',
			data: 'cell_content_id=' + encodeURIComponent(cell_content_id),
			processData: false,
			success: function(data) {
				window.location.reload();
			},
			cache: false
		});
	}
}

function addAttrition(page_id) {
	$.ajax({
		type: 'POST',
		url: siteURL + 'ajax.php?action=add_edit_attrition',
		data: 'page_id=' + encodeURIComponent(page_id) + '&attrition_content_id=0',
		processData: false,
		success: function(data) {
			showPopup(data, { top: 50 });
		},
		cache: false
	})
}

function editAttrition(page_id, attrition_content_id) {
	$.ajax({
		type: 'POST',
		url: siteURL + 'ajax.php?action=add_edit_attrition',
		data: 'page_id=' + encodeURIComponent(page_id) + '&attrition_content_id=' + encodeURIComponent(attrition_content_id),
		processData: false,
		success: function(data) {
			showPopup(data, { top: 50 });
		},
		cache: false
	})
}

function deleteAttrition(attrition_content_id){
	if(confirm('Are you sure you whant to delete attrition?')){
		$.ajax({
			type: 'POST',
			url: siteURL + 'ajax.php?action=delete_attrition',
			data: 'attrition_content_id=' + encodeURIComponent(attrition_content_id),
			processData: false,
			success: function(data) {
				window.location.reload();
			},
			cache: false
		});
	}
}

function editAttritionTitle(page_id) {
	$.ajax({
		type: 'POST',
		url: siteURL + 'ajax.php?action=edit_attrition_molecules_description',
		data: 'page_id=' + encodeURIComponent(page_id),
		processData: false,
		success: function(data) {
			showPopup(data, { top: 50 });
		},
		cache: false
	})
}

function changeOrder(id, from, to){
	var cell_position = new Array();
	var cell_content_id = new Array();
	$('#' + id + ' li').each(function() {
		cell_position[cell_position.length] = $(this).children('.cell_position').val();
		cell_content_id[cell_content_id.length] = $(this).children('.cell_content_id').val();
	});
	
	$.ajax({
		cache: false,
		type: 'POST',
		url: siteURL + 'ajax.php?action=change_regulatory_position',
		data: 'cell_position[]=' + cell_position.join('&cell_position[]=') + '&cell_content_id[]=' + cell_content_id.join('&cell_content_id[]=') + '&from=' + from + '&to=' + to,
		success: function(data) { 
			return true;
		}
	});
}

function checkPagesPosition(){
	$.ajax({
		cache: false,
		type: 'POST',
		url: siteURL + 'ajax.php?action=check_pages_position',
		data: $('#form_edit_cell').serialize(),
		success: function(data) { 
			obj = $.parseJSON(data);
			if(obj.error == 1){
				var error_message = '';
				for(var i in obj.error_message){
					error_message += obj.error_message[i] + '<br />';
				}
				$('.errors').html(error_message);
			}
			else{
				$('#form_edit_cell').submit();
			}
		}
	});
}