<?php include('inc/config.php'); // site configuration ?>
<?php include('inc/functions.php'); // site configuration ?>
<?php
	if(isset($_SESSION['logged'])) {
		// get page and cell data and create file page.php
		// creating file page.php in export folder  
		$myFile = $files_path . "page.php";
		$fh = fopen($myFile, 'w+') or die("can't open file");
		$stringData = "";
		$stringData .= "<?php\n";
		$stringData .= "header (\"content-type: text/xml\");\n\n";
		//chmod($files_path . $myFile, 0777);
		// getting page content and id
		$sql = "SELECT page_id, page_description
							FROM pages
							ORDER BY page_id ASC";
		
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$stringData .= 'if($_GET[\'page\'] == ' . ($res['page_id']-1) . ") {\n";
					// getting cells for this page
					$sql_cell = sprintf("SELECT cell_content_id, position, name, bgColor, triangle, animation, toolTip, box_title, description, overBgColor, cell_id
							FROM cell_pages INNER JOIN cells_content ON cells_content.cell_content_id = cell_pages.cell_id
							WHERE cell_pages.page_id = %d
							ORDER BY position ASC",
							$res['page_id']);
					$result_cell = mysql_query($sql_cell);
					$stringData .= "\t echo '\n\t<cells>\n";
					if(mysql_num_rows($result_cell)){
						while($res_cell = mysql_fetch_array($result_cell)){
							$name = str_replace("'", '&#39;', $res_cell['name']);
							$triangle = !empty($res_cell['triangle'])?$res_cell['triangle']:'none';
							$toolTip = !empty($res_cell['toolTip'])?$res_cell['toolTip']:'none';
							$toolTip = str_replace("'", '&#39;', $toolTip);
							$box_title = !empty($res_cell['box_title'])?$res_cell['box_title']:'';
							$box_title = str_replace("'", '&#39;', $box_title);
							$description = !empty($res_cell['description'])?$res_cell['description']:'none';
							$description = str_replace("'", '&#39;', $description);
							$stringData .= "\t\t<cell>\n";
								$stringData .= "\t\t\t<position>{$res_cell['position']}</position>\n";
								$stringData .= "\t\t\t<name><![CDATA[$name]]></name>\n";
								$stringData .= "\t\t\t<bgColor><![CDATA[{$res_cell['bgColor']}]]></bgColor>\n";
								$stringData .= "\t\t\t<triangle><![CDATA[$triangle]]></triangle>\n";
								$stringData .= "\t\t\t<animation>{$res_cell['animation']}</animation>\n";
								$stringData .= "\t\t\t<toolTip><![CDATA[$toolTip]]></toolTip>\n";
								$stringData .= "\t\t\t<description><![CDATA[$description]]></description>\n";
								$stringData .= "\t\t\t<overBgColor><![CDATA[{$res_cell['overBgColor']}]]></overBgColor>\n";
								$stringData .= "\t\t\t<title><![CDATA[{$box_title}]]></title>\n";
							$stringData .= "\t\t</cell>\n";
						}
					}
					$stringData .= "\t</cells>';\n";
				$stringData .= "}\n";
			}
		}

		$stringData .= "?>";
		fwrite($fh, $stringData);
		fclose($fh);
		
		// creating file attrition.php in export folder  
		$myFile = $files_path . "attrition.php";
		$fh = fopen($myFile, 'w+') or die("can't open file");
		$stringData = "";
		$stringData .= "<?php\n";
		$stringData .= "header (\"content-type: text/xml\");\n\n";
		//chmod($files_path . $myFile, 0777);
		// getting page content and id
		$sql = "SELECT page_id, page_description, page_attrition_description
							FROM pages
							ORDER BY page_id ASC";
		
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$page_description = str_replace("'", '&#39;', $res['page_description']);
				$page_attrition_description = str_replace("'", '&#39;', $res['page_attrition_description']);
				$stringData .= 'if($_GET[\'page\'] == ' . ($res['page_id']-1) . ") {\n";
					$stringData .= "\t echo '\n\t<others>\n";
					// getting attritions for this page
					$sql_attrition = sprintf("SELECT attrition_content_id, attrition_pages.page_id, name, bgColor, triangle, toolTip, box_title, description, overBgColor
							FROM attritions_content INNER JOIN attrition_pages ON attritions_content.attrition_content_id = attrition_pages.attrition_id
							WHERE attrition_pages.page_id = %d
							ORDER BY attritions_content.attrition_content_id ASC",
							$res['page_id']);
					$result_attrition = mysql_query($sql_attrition);
					$stringData .= "\t\t<attrition>\n";
					if(mysql_num_rows($result_attrition)){
						while($res_attrition = mysql_fetch_array($result_attrition)){
							$name = str_replace("'", '&#39;', $res_attrition['name']);
							$triangle = !empty($res_attrition['triangle'])?$res_attrition['triangle']:'none';
							$toolTip = !empty($res_attrition['toolTip'])?$res_attrition['toolTip']:'none';
							$toolTip = str_replace("'", '&#39;', $toolTip);
							$box_title = !empty($res_attrition['box_title'])?$res_attrition['box_title']:'';
							$box_title = str_replace("'", '&#39;', $box_title);
							$description = !empty($res_attrition['description'])?$res_attrition['description']:'none';
							$description = str_replace("'", '&#39;', $description);
							$stringData .= "\t\t<cell>\n";
								$stringData .= "\t\t\t<name><![CDATA[$name]]></name>\n";
								$stringData .= "\t\t\t<bgColor><![CDATA[{$res_attrition['bgColor']}]]></bgColor>\n";
								$stringData .= "\t\t\t<triangle><![CDATA[$triangle]]></triangle>\n";
								$stringData .= "\t\t\t<toolTip><![CDATA[$toolTip]]></toolTip>\n";
								$stringData .= "\t\t\t<description><![CDATA[$description]]></description>\n";
								$stringData .= "\t\t\t<overBgColor><![CDATA[{$res_attrition['overBgColor']}]]></overBgColor>\n";
								$stringData .= "\t\t\t<title><![CDATA[{$box_title}]]></title>\n";
							$stringData .= "\t\t</cell>\n";
						}
					}
					$stringData .= "\t\t</attrition>\n";
					$stringData .= "\t\t<pageDescription><![CDATA[{$page_description}]]></pageDescription>\n";
					$stringData .= "\t\t<legend><![CDATA[{$page_attrition_description}]]></legend>\n";
					$stringData .= "\t</others>';\n";
				$stringData .= "}\n";
			}
		}
		
		
		$stringData .= "?>";
		fwrite($fh, $stringData);
		fclose($fh);
		
		
		// creating file attrition.php in export folder  
		$myFile = $files_path . "text.php";
		$fh = fopen($myFile, 'w+') or die("can't open file");
		$stringData = "";
		$stringData .= "<?php\n";
		$stringData .= "header (\"content-type: text/xml\");\n\n";
		//chmod($files_path . $myFile, 0777);
		// getting page content and id
		$sql = "SELECT value
				FROM general_information";
		
		$result = mysql_query($sql);
		$stringData .= "\t echo '\n\t<texts>\n";
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
					$value = str_replace("'", '&#39;', $res['value']);
					
					$stringData .= "\t\t<txt>\n";
					$stringData .= "\t\t\t<txt><![CDATA[{$value}]]></txt>\n";
					$stringData .= "\t\t</txt>\n";
			}
		}
		$stringData .= "\t</texts>';\n";
		
		$stringData .= "?>";
		fwrite($fh, $stringData);
		fclose($fh);
		
		echo 'export done!';
	}
	else{
		header("Location: $site_url");
	}
?>
