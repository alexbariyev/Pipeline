<div id="login-content">
	<form method="post" action="<?php echo $site_url; ?>index.php" id="form_login" name="fom_login">
		<p>
			<label>Username</label>
			<input type="text" name="username" id="username" value="<?php echo isset($_POST['username'])?$_POST['username']:'';?>" />
		</p>
		<p>
			<label>Password</label>
			<input type="password" name="password" id="password" value="<?php echo isset($_POST['password'])?$_POST['password']:'';?>" />
		</p>
		<p>
			<input type="submit" name="login" id="login" value="Login" />
		</p>
		<?php if(!empty($error_message)) { ?>
			<label class="error"><?php echo $error_message; ?></label>
		<?php } ?>
	</form>
</div>