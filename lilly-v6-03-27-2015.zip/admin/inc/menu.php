<div id="menu">
	<div class="section">
		<label class="section_title">Pages</label>
		<ul class="section_content">
			<?php 
				echo display_pages(0,0, isset($_GET['page_id'])?$_GET['page_id']:'1');
			?>
		</ul>
	</div>
	<div class="section">
		<label class="section_title"><a href="<?php echo $site_url; ?>index.php?pipeline_info">Pipeline Information</a></label>
		<label class="section_title"><a href="<?php echo $site_url; ?>index.php?clinical_trials">Clinical Trials</a></label>
		<label class="section_title"><a href="<?php echo $site_url; ?>index.php?analytics">Google Analytics</a></label>
	</div>
	<div class="section">
		<label class="section_title">General information</label>
		<form method="post" action="<?php echo $site_url; ?>ajax.php?page_id=<?php echo isset($_GET['page_id'])?$_GET['page_id']:'1'; ?>&action=save_general_information" name="form_save_general_information" id="form_save_general_information">
			<p>
				<label>Data last updated</label>
				<input type="text" name="data_last_update" id="data_last_update" value="<?php echo $general['data_last_update']; ?>" />
			</p>
			<p>
				<label>Since</label>
				<input type="text" name="since" id="since" value="<?php echo $general['since']; ?>" />
			</p>
			<p>
				<input type="submit" name="save_page_description" value="Save general info" />
			</p>
		</form>
	</div>
	<div class="section">
		<a href="<?php echo $site_url; ?>export_xls.php" target="_blank" title="Export data">Export Excel</a>
	</div>
	<div class="section">
		<a href="<?php echo $site_url; ?>export.php" target="_blank" title="Export data">Export Data</a>
	</div>
	<div class="section">
		<a href="<?php echo $site_url; ?>download.php" title="Download">Download files</a>
	</div>
	<div class="section">
		<a href="<?php echo $site_url; ?>?logout" title="Logout">Logout</a>
	</div>
</div>