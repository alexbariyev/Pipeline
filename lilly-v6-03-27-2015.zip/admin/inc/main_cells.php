<?php 
	$page_id = !isset($_GET['page_id']) ? 1 : $_GET['page_id'];
	$size = ($page_id == 1 || $page_id == 13 || $page_id == '17' || $page_id == '18') ? '' : 'big';
?>
<div id="content-center">
	<div id="cell-container">
		<div class="cells-container">
			<div class="cells-container-inner">
				<form class="page_title" method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_title">
					<input style="width: 450px; text-align: center;" type="text" name="title_1" value="<?php echo $general['title_1']; ?>" />
					<input type="submit" name="save_title" value="Save" />
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
				</form>
				<ul class="molecule-container regulatory">
					<?php 
						$class = ($page_id == 1) ? '' : 'regulatory';
						$phase = 'regulatory';
						for($i=1; $i<=6; $i++) { ?>
						<?php include('inc/cells/cell_content.php'); ?>
					<?php } ?>
				</ul>
			</div>
		</div>
		<div class="cells-container">
			<div class="cells-container-inner">
				<form class="page_title" method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_title">
					<input style="width: 450px; text-align: center;" type="text" name="title_2" value="<?php echo $general['title_2']; ?>" />
					<input type="submit" name="save_title" value="Save" />
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
				</form>
				<ul class="molecule-container nilex">
					<?php 
						$class = ($page_id == 1) ? '' : 'nilex';
						$phase = 'nilex';
						for($i=7; $i<=36; $i++) { ?>
						<?php include('inc/cells/cell_content.php'); ?>
					<?php } ?>
				</ul>
			</div>
		</div>
		
		<div class="cells-container">
			<div class="cells-container-inner <?php echo $class; ?>">
				<form class="page_title" method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_title">
					<input style="width: 450px; text-align: center;" type="text" name="title_3" value="<?php echo $general['title_3']; ?>" />
					<input type="submit" name="save_title" value="Save" />
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
				</form>
				<ul class="molecule-container phase-3">
				<?php 
					$class = ($page_id == 1) ? '' : 'phase-3';
					$phase = 'phase-3';
					for($i=37; $i<=54; $i++) { ?>
					<?php include('inc/cells/cell_content.php'); ?>
				<?php } ?>
				</ul>
			</div>
		</div>
		<div class="cells-container">
			<div class="cells-container-inner">
				<form class="page_title" method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_title">
					<input style="width: 450px; text-align: center;" type="text" name="title_4" value="<?php echo $general['title_4']; ?>" />
					<input type="submit" name="save_title" value="Save" />
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
				</form>
				<ul class="molecule-container phase-2">
					<?php
						$class = ($page_id == 1) ? '' : 'phase-2';
						$phase = 'phase-2';
						for($i=55; $i<=90; $i++) { ?>
						<?php include('inc/cells/cell_content.php'); ?>
					<?php } ?>
				</ul>
			</div>
		</div>
		<div class="cells-container">
			<div class="cells-container-inner">
				<form class="page_title" method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_title">
					<input style="width: 450px; text-align: center;" type="text" name="title_5" value="<?php echo $general['title_5']; ?>" />
					<input type="submit" name="save_title" value="Save" />
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
				</form>
				<ul class="molecule-container phase-1">
					<?php
						$class = ($page_id == 1) ? '' : 'phase-1';
						$phase = 'phase-1';
						for($i=91; $i<=126; $i++) { ?>
						<?php include('inc/cells/cell_content.php'); ?>
					<?php } ?>
				</ul>
			</div>
		</div>
	</div>
	<div class="content_section">
		<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_description" name="form_save_page_description" id="form_save_page_description">
			<p>
				<label>Page description</label>
				<textarea name="page_description" id="page_description"><?php echo $data['page_description']?></textarea>
			</p>
			<p>
				<input type="submit" name="save_page_description" value="Save page description" />
				<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
			</p>
		</form>
	</div>
</div>
