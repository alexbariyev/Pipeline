<div id="content-center">
	<div class="content_section">
		<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_analytics" name="form_save_analytics" id="form_save_analytics">
			<p>
				<label>Google Analytics:</label>
			</p>
			<p>
				<textarea rows="20" cols="80" name="analytics" id="analytics"><?php echo $general['analytics']; ?></textarea>
			</p>
			<p>
				<input type="submit" name="save_analytics" value="Save Analytics code" />
			</p>
		</form>
	</div>
</div>