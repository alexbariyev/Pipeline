<?php 
	function do_login($post){
		if(!empty($post)){
			// check username and password
			$username = strip_tags($post['username']);
			$password = md5(strip_tags($post['password']));
			$query = "SELECT `user_id` FROM `users` WHERE `username` = '$username' AND `password` = '$password'";
			$query_sql = mysql_query($query);
			if(mysql_num_rows($query_sql)){
				$user_sql = mysql_fetch_array($query_sql);
				$_SESSION['logged'] = $user_sql['user_id'];
				return true;
			}
			return false;
		}
	}
	
	function logout(){
		session_destroy();
	}
	// check if page has sons
	function page_has_sons($page_id){
		$sql = sprintf("SELECT page_id 
							FROM pages
							WHERE parent_id = %d
						", $page_id);
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			return true;
		}
		return false;
	}
	
	// check if page is a parent page
	function page_is_parent($parent_id, $current_page){
		$sql = sprintf("SELECT parent_id 
							FROM pages
							WHERE page_id = %d
						", $current_page);
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			$result_array = mysql_fetch_array($result);
			if($parent_id == $result_array['parent_id']){
				return true;
			}
			return false;
		}
		return false;
	}
	
	function display_pages($parent = 0, $level = 0, $current_page = 0) {
	   $sql = sprintf("SELECT page_name, page_id
							FROM pages
							WHERE parent_id = %d ORDER BY page_position ASC",
							$parent);
		$result = mysql_query($sql);
		$result_html = '';
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				if(!page_has_sons($res['page_id'])){
					$href = "index.php?page_id={$res['page_id']}";
					$onclick = '';
				}
				else {
					$href = '#';
					$onclick = "toggle_menu('parent_{$res['page_id']}'); return false";
				}
				if((isset($_GET['page_id']) && $_GET['page_id'] == $res['page_id']) || (!isset($_GET['page_id']) && $res['page_id'] == '1')){
					$class = 'active';
				}
				else {
					$class = '';
				}
				if(page_is_parent($res['page_id'], $current_page)){
					$style = 'display: block';
				}
				else {
					$style = 'display: none;';
				}
				$result_html .= "<li class='{$class}' id='page_{$res['page_id']}'><a href='$href' onclick=\"$onclick\">- {$res['page_name']}</a>";
					if(page_has_sons($res['page_id']) == true){
						$result_html .= "<ul id='parent_{$res['page_id']}' style='$style'>";
							$result_html .= display_pages($res['page_id'], $level++, $current_page);
						$result_html .= '</ul>';
					}
				$result_html .= '</li>';
			}
		}
		return $result_html;
	}
	
	function get_page_data($page_id = 1){
		$data = array();
		/*
		if($page_id == 1){
			$sql = sprintf("SELECT cell_content_id, position, name, box_title, bgColor, triangle, animation, toolTip, description, overBgColor, cell_id, business_area, display_business 
							FROM cell_pages INNER JOIN cells_content ON cells_content.cell_content_id = cell_pages.cell_id
							ORDER BY position ASC",
							$page_id);
		}
		else{
			$sql = sprintf("SELECT cell_content_id, cell_page_postitions.position, name, box_title, bgColor, triangle, animation, toolTip, description, overBgColor, cell_pages.cell_id, business_area, display_business 
							FROM cell_pages 
							INNER JOIN cells_content ON cells_content.cell_content_id = cell_pages.cell_id
							INNER JOIN cell_page_postitions ON cell_page_postitions.cell_id = cell_pages.cell_id AND cell_page_postitions.page_id = cell_pages.page_id
							WHERE cell_pages.page_id = %d
							ORDER BY cell_page_postitions.position ASC",
							$page_id);
		}
		*/
		$sql = sprintf("SELECT cell_content_id, cell_page_postitions.position, name, box_title, bgColor, triangle, animation, toolTip, description, news_box, overBgColor, cell_pages.cell_id, business_area, display_business, legend_name 
							FROM cell_pages 
							INNER JOIN cells_content ON cells_content.cell_content_id = cell_pages.cell_id
							INNER JOIN cell_page_postitions ON cell_page_postitions.cell_id = cell_pages.cell_id AND cell_page_postitions.page_id = cell_pages.page_id
							LEFT JOIN legend ON legend.legend_identifier = cells_content.triangle
							WHERE cell_pages.page_id = %d
							ORDER BY cell_page_postitions.position ASC",
							$page_id);
		
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$data["{$res['position']}"]['cell_content_id'] = $res['cell_content_id']; 
				$data["{$res['position']}"]['position'] = $res['position']; 
				$data["{$res['position']}"]['name'] = $res['name']; 
				$data["{$res['position']}"]['box_title'] = $res['box_title']; 
				$data["{$res['position']}"]['bgColor'] = $res['bgColor']; 
				$data["{$res['position']}"]['triangle'] = $res['triangle']; 
				$data["{$res['position']}"]['animation'] = $res['animation']; 
				$data["{$res['position']}"]['toolTip'] = $res['toolTip']; 
				$data["{$res['position']}"]['description'] = $res['description']; 
				$data["{$res['position']}"]['news_box'] = $res['news_box']; 
				$data["{$res['position']}"]['overBgColor'] = $res['overBgColor'];
				$data["{$res['position']}"]['business_area'] = $res['business_area'];
				$data["{$res['position']}"]['display_business'] = $res['display_business'];
				$data["{$res['position']}"]['legend_name'] = $res['legend_name'];
			}
		}
		$sql = sprintf("SELECT page_description, page_attrition_description
							FROM pages
							WHERE page_id = %d
							",$page_id);
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			$res = mysql_fetch_array($result);
			$data['page_description'] = $res['page_description'];
			$data['page_attrition_description'] = $res['page_attrition_description'];
		}
		return $data;
	}
	function get_cell_content($cell_content_id = 0){
		$data = array();
		$data['pages'] = array();
		$sql = sprintf("SELECT cell_content_id, name, bgColor, triangle, animation, toolTip, box_title, description, news_box, overBgColor, business_area, display_business
							FROM cells_content
							WHERE cell_content_id = %d
							LIMIT 1", $cell_content_id);
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			$res = mysql_fetch_array($result);
			$data['cell_content_id'] = $res['cell_content_id'];
			$data['name'] = $res['name']; 
			$data['bgColor'] = $res['bgColor']; 
			$data['triangle'] = $res['triangle']; 
			$data['animation'] = $res['animation']; 
			$data['toolTip'] = $res['toolTip']; 
			$data['box_title'] = $res['box_title']; 
			$data['description'] = $res['description']; 
			$data['overBgColor'] = $res['overBgColor'];
			$data['business_area'] = $res['business_area'];
			$data['display_business'] = $res['display_business'];
			
			$data['news_box'] = $res['news_box']; // new addition 07.03.2013
			// get pages where the cell is
			$sql = sprintf("SELECT page_id
							FROM cell_pages
							WHERE cell_id = %d", $data['cell_content_id']);
			$result = mysql_query($sql);
			if(mysql_num_rows($result)){
				$i = 0;
				while($page = mysql_fetch_array($result)){
					$data['pages'][] = $page['page_id'];
				}
			}
		}
		return $data;
	}
	
	function get_page_attritions($page_id = 0){
		$data = array();
		$i = 0;
		$sql = sprintf("SELECT attrition_content_id, attrition_pages.page_id, name, bgColor, triangle, toolTip, description, overBgColor
							FROM attritions_content INNER JOIN attrition_pages on attritions_content.attrition_content_id = attrition_pages.attrition_id
							WHERE attrition_pages.page_id = %d
							ORDER BY attritions_content.attrition_content_id ASC
						", $page_id);
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$data[$i]['attrition_content_id'] = $res['attrition_content_id']; 
				$data[$i]['name'] = $res['name']; 
				$data[$i]['bgColor'] = $res['bgColor']; 
				$data[$i]['triangle'] = $res['triangle']; 
				$data[$i]['animation'] = $res['animation']; 
				$data[$i]['toolTip'] = $res['toolTip']; 
				$data[$i]['description'] = $res['description']; 
				$data[$i]['overBgColor'] = $res['overBgColor'];
				$i++;
			}
		}
		return $data;
	}
	
	function get_attrition_content($attrition_content_id = 0){
		$data = array();
		$data['pages'] = array();
		$sql = sprintf("SELECT attrition_content_id, page_id, name, bgColor, triangle, toolTip, box_title, description, overBgColor
							FROM attritions_content
							WHERE attrition_content_id = %d
							LIMIT 1", $attrition_content_id);
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			$res = mysql_fetch_array($result);
			$data['attrition_content_id'] = $res['attrition_content_id']; 
			$data['page_id'] = $res['page_id']; 
			$data['name'] = $res['name']; 
			$data['bgColor'] = $res['bgColor']; 
			$data['triangle'] = $res['triangle']; 
			$data['toolTip'] = $res['toolTip'];
			$data['box_title'] = $res['box_title']; 
			$data['description'] = $res['description']; 
			$data['overBgColor'] = $res['overBgColor'];
			// get pages where the cell is
			$sql = sprintf("SELECT page_id
							FROM attrition_pages
							WHERE attrition_id = %d", $data['attrition_content_id']);
			$result = mysql_query($sql);
			if(mysql_num_rows($result)){
				$i = 0;
				while($page = mysql_fetch_array($result)){
					$data['pages'][] = $page['page_id'];
				}
			}
		}
		return $data;
	}
	
	function get_general_data(){
		$data = array();
		$sql = "SELECT name, value FROM general_information";
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$data["{$res['name']}"] = $res['value']; 
			}
		}
		return $data;
	}
	
	function get_full_legend_data(){
		$data = array();
		$sql = "SELECT name, content FROM full_legend";
		$result = mysql_query($sql);
		if(mysql_num_rows($result)){
			while($res = mysql_fetch_array($result)){
				$data["{$res['name']}"] = $res['content']; 
			}
		}
		return $data;
	}
	
	function get_legend($html = ''){
		$html .= '<div class="legend">';
			$html .= '<p>';
				$html .= '<label><b>Legend</b></label>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>cdecff</label><i style="background-color: #cdecff;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>238dce</label><i style="background-color: #238dce;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>cccc00</label><i style="background-color: #cccc00;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>797900</label><i style="background-color: #797900;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>ffffa6</label><i style="background-color: #ffffa6;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>e76a2e</label><i style="background-color: #e76a2e;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>f0bdcc</label><i style="background-color: #f0bdcc;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>9e4363</label><i style="background-color: #9e4363;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>ee1c25</label><i style="background-color: #ee1c25;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>00a652</label><i style="background-color: #00a652;">&nbsp;</i>';
			$html .= '</p>';
			$html .= '<p>';
				$html .= '<label>005f97</label><i style="background-color: #005f97;">&nbsp;</i>';
			$html .= '</p>';
		$html .= '</div>';
		
		return $html;
	}
	
	function get_pages(){
		$sql = mysql_query("SELECT page_id, page_name FROM pages");
		$data = array();
		if(mysql_num_rows($sql)){
			$i = 0;
			while($res = mysql_fetch_array($sql)){
				$data[$i]['page_id'] = $res['page_id'];
				$data[$i]['page_name'] = $res['page_name'];
				$i++;
			}
		}
		
		return $data;
	}
	
	function get_cell_size($page_id = 0, $cell_id = 0){
		$sql = mysql_query("SELECT size FROM cell_page_sizes WHERE cell_id = {$cell_id} AND page_id = {$page_id}");
		$data = array();
		if(mysql_num_rows($sql)){
			$res = mysql_fetch_array($sql);
			return $res['size'];
		}
		return false;
	}
	
	function get_export_data($res = array(), $i = 1, $size = '', $phase = ''){
		if($phase == 'Select New Indication or Line Extension (NILEX)'){
			$phase = 'Select NILEX';
		}
		$empty = !empty($res) ? '' : 'empty';
		$stringData = '';
		$stringData .= "<li id='cell-{$i}' class='{$size} {$empty}'>";
			if(!empty($res)){
				$molecule_type = !empty($res['business_area'])?$res['business_area']:'';
				
				$toolTip = ($res['toolTip']!='none')?'tooltip':'';
				$stringData .= "
					<table cellspacing=\"0\" cellpadding=\"0\"><tr><td>
						<a id=\"click-content-{$i}\" class=\"{$size} {$size}{$res['bgColor']}_cell {$size}{$toolTip}_under\" title=\"CLICK FOR MORE\">";
						if(!empty($res['triangle']) && $res['triangle'] != 'none'){
							$stringData .="<img class=\"minfoimg\" align=\"absmiddle\" src=\"./img/{$size}{$res['triangle']}.png\" alt=\"\" />";
						}
					$stringData .="
							<div class=\"molecule-inner-content\"><label>". html_entity_decode($res['name'], ENT_NOQUOTES, "UTF-8") . "</label><label class=\"toolt\">". html_entity_decode($res['toolTip'], ENT_NOQUOTES, "UTF-8") . "</label><label class=\"click_for_more\">Click for more</label></div>
						</a>
					</td></tr></table>
				";
				if(!empty($res['description']) && $res['description'] != 'none'){
					$stringData .= "
						<div class=\"content-popup {$size}\" id=\"content-{$i}\">
							<div class=\"molecule-title\">
					";
								
								if(!empty($res['triangle']) && $res['triangle'] != 'none'){
									$stringData .="
										<div class=\"minfobg\"><img src=\"./img/{$size}{$res['triangle']}.png\" alt=\"\" /></div>
									";
								}
					$label = '';
					$box_title = html_entity_decode($res['box_title'], ENT_NOQUOTES, "UTF-8");
					if($res['display_business'] == '1') {
						$label = 'Business area: ';
					}
					$stringData .= "
								<div class=\"mtitle DINBold\">{$box_title}</div>
								<div class=\"molecule-position\">
									<label>{$phase}</label>
									<label>{$label} {$molecule_type}</label>";
									if(!empty($res['triangle']) && $res['triangle'] != 'none'){
										$stringData .="<label style='display:block;'>{$res['legend_name']}</label>";
									}
					$stringData .="
								</div>
							</div>
							
							<div class=\"molecule-description\">
								". html_entity_decode($res['description'] . ' <br /><br /> '  . $res['news_box'], ENT_NOQUOTES, "UTF-8") . "
							</div>
							<a class=\"bClose\">&nbsp;</a>
						</div>
						<script type=\"text/javascript\">
							$(\"#click-content-{$i}\").bind('click', function(){
								$(\"#content-{$i}\").bPopup();
								return false;
							});
						</script>
					";
				}
			}
			else{
				$stringData .= "
					<span class=\"{$size} {$size}empty_cell no_bg\">&nbsp;</span>
				";
			}
		$stringData .= "</li>";
		
		return $stringData;
	}
	
	function reorder_positions(){
		$query_1 = mysql_query('SELECT cell_id, position FROM `cell_page_postitions` WHERE `page_id` = 1 ORDER BY `cell_id` ASC');
		if(mysql_num_rows($query_1)){
			while($res = mysql_fetch_array($query_1)){
				$sql = sprintf("UPDATE `cell_page_postitions` SET `position` = '%s' WHERE `cell_id` = %s",
							$res['position'], $res['cell_id']);
				$query_2 = mysql_query($sql);
			}
		}
	}
	
	function get_molecule_legend(){
		$data = array();
		$sql = "SELECT `legend_identifier`,`legend_name`,`legend_tooltip` FROM `legend` ORDER BY `legend_id`";
		$query = mysql_query($sql);
		if(mysql_num_rows($query)){
			$i = 0;
			while($res = mysql_fetch_array($query)){
				$data[$i]['legend_identifier'] = $res['legend_identifier'];
				$data[$i]['legend_name'] = $res['legend_name'];
				$data[$i]['legend_tooltip'] = $res['legend_tooltip'];
				$i++;
			}
		}
		return $data;
	}
?>