<!DOCTYPE html>
<html>
	<head>
	   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	   <meta name="GENERATOR" content="">
	   <meta name="description" content="shell">
	   <meta name="keywords" content="">
	   <title>Shell</title>
	   <link type="text/css" media="screen" rel="stylesheet" href="<?php echo $base_url; ?>fonts/stylesheet.css" />
	   <link type="text/css" media="screen" rel="stylesheet" href="<?php echo $base_url; ?>site.css" />
	   <link type="text/css" media="screen" rel="stylesheet" href="<?php echo $site_url; ?>css/index.css" />
	   <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
	   <script type="text/javascript" src="<?php echo $site_url; ?>js/tiny_mce/jquery.tinymce.js"></script>
	   <script type="text/javascript" src="<?php echo $site_url; ?>js/jquery.validate.min.js"></script>
	   <script type="text/javascript" src="<?php echo $site_url; ?>js/index.js"></script>
	   <script type="text/javascript" src="<?php echo $site_url; ?>js/jquery-ui-1.8.11.custom.min.js"></script>
	   <script type="text/javascript">
			var siteURL = '<?php echo $site_url; ?>';
		</script>
	</head>
	<body>
		<div id='lightbox-bg'></div>
		<div id='popup-window'></div>
		<div id="container">
			<div id="header">
				<img src="<?php echo $base_url; ?>img/header.png" alt="" />
			</div>
