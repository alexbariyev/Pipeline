<div id="content-center">
	<div class="content_section">
		<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_pipeline_info" name="form_save_pipeline_info" id="form_save_pipeline_info">
			<p>
				<label>Pipeline inforamtion</label>
			</p>
			<p>
				<textarea rows="20" cols="80" name="pipeline_info" id="pipeline_info"><?php echo $general['pipeline_info']; ?></textarea>
			</p>
			<p>
				<input type="submit" name="save_pipeline_info" value="Save pipeline info" />
			</p>
		</form>
	</div>
</div>