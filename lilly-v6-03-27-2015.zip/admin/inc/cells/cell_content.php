<li id="cell-<?php echo $i; ?>" onmouseout="hideCellActions(this);" onmouseover="showCellActions(this);" class="<?php echo $class; ?> table_cell editable <?php echo $size; ?>">
	<?php 
		if(!empty($data[$i])){
	?>
		<a class="<?php echo $size; ?> <?php echo $size; ?><?php echo $data[$i]['bgColor']; ?>_cell tooltip" title="<?php echo !empty($data[$i]['name'])?$data[$i]['name']:''; ?>">
			<?php if(!empty($data[$i]['triangle']) && $data[$i]['triangle'] != 'none'){ ?>
				<img class="minfoimg" align="absmiddle" src="../img/<?php echo $size; ?><?php echo $data[$i]['triangle']; ?>.png" alt="" />
			<?php } ?>
			<label><?php echo !empty($data[$i]['name'])?html_entity_decode($data[$i]['name'], ENT_NOQUOTES, "UTF-8"):''; ?></label>
		</a>
	<?php
		}

		else{
	?>
		<span class="<?php echo $size; ?> <?php echo $size; ?>empty_cell">&nbsp;</span>
	<?php 
		}
	?>
	<?php if($page_id == 1) { ?>
		<a href="#" onclick='editCellContent("<?php echo $page_id; ?>", "<?php echo $i; ?>", "<?php echo (!empty($data[$i]['cell_content_id'])) ? $data[$i]['cell_content_id'] : 0; ?>", "<?php echo $phase; ?>"); return false;' title="Edit cell" class="cell-ops edit-cell">&nbsp;</a>
	<?php } ?>
	<?php if(!empty($data[$i]['cell_content_id']) && $page_id == 1) { ?>
		<a href="#" onclick='deleteCellContent("<?php echo $data[$i]['cell_content_id']; ?>"); return false;' title="Delete cell" class="cell-ops delete-cell">&nbsp;</a>
	<?php } ?>
	<input type="hidden" class="cell_position" value="<?php echo $i; ?>" />
	<?php if(!empty($data[$i]['cell_content_id'])) { ?>
		<input type="hidden" class="cell_content_id" value="<?php echo $data[$i]['cell_content_id']; ?>" />
	<?php } ?>
	<input type="hidden" class="phase" value="<?php echo $phase; ?>" />
</li>

<script type="text/javascript">
	$(function() {
		$( "<?php echo !empty($class) ? ".{$class} " : ''; ?>.table_cell" ).draggable({ revert: "invalid" });
		$( "<?php echo !empty($class) ? ".{$class} " : ''; ?>.table_cell" ).droppable({
			<?php if(!empty($class)) { ?>
				greedy: true,
				accept: ".<?php echo $class; ?>",
			<?php } ?>
			drop: function( event, ui ) {
				var dragged_id = $(ui.draggable).attr("id");
				var dragged_phase = $(ui.draggable).find('.phase').val();

				var dropped_id = $(this).attr('id');
				var dropped_phase = $(this).find('.phase').val();
				
				$.ajax({
					cache: false,
					type: 'POST',
					url: siteURL + 'ajax.php?action=change_cell_position',
					data: 'dragged_phase=' + dragged_phase + '&dropped_phase=' + dropped_phase + '&dragged_position=' + $(ui.draggable).attr("id") + '&dropped_position=' + $(this).attr('id') + '&page_id=<?php echo $page_id; ?>',
					success: function(data) { 
						var obj = jQuery.parseJSON(data);
						//alert(obj.dragged_bgColor);
						var dragged_html = '';
						var dropped_html = '';

						if(obj.dragged_id){
							dropped_html += '<a class="<?php echo $size; ?> <?php echo $size; ?>'+obj.dragged_bgColor+'_cell tooltip">';
								if(obj.dragged_triangle != ''){
									dropped_html += '<img class="minfoimg" align="absmiddle" alt="" src="../img/<?php echo $size; ?>'+obj.dragged_triangle+'.png">';
								}
								dropped_html += '<label>'+obj.dragged_name+'</label>';
							dropped_html += '</a>';
						}
						else{
							dropped_html += '<span class="<?php echo $size; ?> <?php echo $size; ?>empty_cell">&nbsp;</span>';
						}
						
						if(obj.dragged_id){
							<?php if($page_id == 1) { ?>
								dropped_html += '<a class="cell-ops edit-cell" title="Edit cell" onclick="editCellContent(1, '+obj.dropped_position+', '+obj.dragged_id+', \'' + dropped_phase + '\'); return false;" href="#" style="display: none;">&nbsp;</a>';
								dropped_html += '<a class="cell-ops delete-cell" title="Delete cell" onclick="deleteCellContent('+obj.dragged_id+'); return false;" href="#" style="display: none;">&nbsp;</a>';
							<?php } ?>
							dropped_html += '<input type="hidden" value="'+obj.dropped_position+'" class="cell_position">';
							dropped_html += '<input type="hidden" value="'+obj.dragged_id+'" class="cell_content_id">';
						}
						else{
							<?php if($page_id == 1) { ?>
								dropped_html += '<a class="cell-ops edit-cell" title="Edit cell" onclick="editCellContent(1, '+obj.dropped_position+', 0, \'' + dropped_phase + '\'); return false;" href="#" style="display: none;">&nbsp;</a>';
							<?php } ?>
							dropped_html += '<input type="hidden" value="'+obj.dropped_position+'" class="cell_position">';
						}
						dropped_html += '<input type="hidden" value="'+dropped_phase+'" class="phase">';
						$('#'+dropped_id).html(dropped_html);
						
						if(obj.dropped_id){
							dragged_html += '<a class="<?php echo $size; ?> <?php echo $size; ?>'+obj.dropped_bgColor+'_cell tooltip">';
								if(obj.dropped_triangle != ''){
									dragged_html += '<img class="minfoimg" align="absmiddle" alt="" src="../img/<?php echo $size; ?>'+obj.dropped_triangle+'.png">';
								}
								dragged_html += '<label>'+obj.dropped_name+'</label>';
							dragged_html += '</a>';
							
						}
						else{
							dragged_html += '<span class="<?php echo $size; ?> <?php echo $size; ?>empty_cell">&nbsp;</span>';
							
						}
						if(obj.dropped_id){
							<?php if($page_id == 1) { ?>
								dragged_html += '<a class="cell-ops edit-cell" title="Edit cell" onclick="editCellContent(1, '+obj.dragged_position+', '+obj.dropped_id+', \'' + dragged_phase + '\'); return false;" href="#" style="display: none;">&nbsp;</a>';
								dragged_html += '<a class="cell-ops delete-cell" title="Delete cell" onclick="deleteCellContent('+obj.dragged_id+'); return false;" href="#" style="display: none;">&nbsp;</a>';
							<?php } ?>
							dragged_html += '<input type="hidden" value="'+obj.dragged_position+'" class="cell_position">';
							dragged_html += '<input type="hidden" value="'+obj.dropped_id+'" class="cell_content_id">';
						}
						else{
							<?php if($page_id == 1) { ?>
								dragged_html += '<a class="cell-ops edit-cell" title="Edit cell" onclick="editCellContent(1, '+obj.dragged_position+', 0, \'' + dragged_phase + '\'); return false;" href="#" style="display: none;">&nbsp;</a>';
							<?php } ?>
							dragged_html += '<input type="hidden" value="'+obj.dragged_position+'" class="cell_position">';
						}
						dragged_html += '<input type="hidden" value="'+dragged_phase+'" class="phase">';
						
						
						$('#'+dragged_id).html(dragged_html);
						$('#'+dragged_id).css('top', '0px');
						$('#'+dragged_id).css('left', '0px');
						$('#'+dragged_id).css('right', '0px');
						$('#'+dragged_id).css('bottom', '0px');
					}
				});
				/*
				$(this)
					.addClass( "ui-state-highlight" )
					.find( "p" )
						.html( "Dropped!" );
				*/
				/*
				alert($(ui.draggable).attr("id"));
				alert($(this).attr('id'));
				*/
			}
		});
	});

</script>
