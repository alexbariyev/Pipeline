<!-- /TinyMCE -->
<script type="text/javascript">
$(document).ready(function(){
	init_tinymce('tinyMce');
});
</script>
<div id="content-center">
	<!--<h1 class="big_h1">UNDERSTANDING LILLY'S CLINICAL DEVELOPMENT <span>PIPELINE</span> WEBSITE</h1>-->
	<div class="content_section">
		<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_full_legend" name="form_save_full_legend" id="form_save_full_legend">
			<p>
				<label>Top paragraph</label>
			</p>
			<p>
				<textarea rows="20" cols="80" name="top_p" id="top_p" class="tinyMce"><?php echo $full_legend['top_p']; ?></textarea>
			</p>
			<p>
				<label>Abbreviations</label>
			</p>
			<p>
				<textarea rows="20" cols="80" name="abbrev" id="abbrev" class="tinyMce"><?php echo $full_legend['abbrev']; ?></textarea>
			</p>
			<p>
				<label>Frequently Asked Questions</label>
			</p>
			<p>
				<textarea rows="20" cols="80" name="faq" id="faq" class="tinyMce"><?php echo $full_legend['faq']; ?></textarea>
			</p>
			<p>
				<input type="submit" name="save_full_legend" value="Save full legend" />
			</p>
		</form>
	</div>
</div>