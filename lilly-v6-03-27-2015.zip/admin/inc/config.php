<?php 
	// start session for adminstration
	session_start();
	
	// Database connection
	$db_host = 'localhost';
	$db_user = 'brucemcm_v6';
	$db_pass = 'e7vv.aI3.[;Z';

	$con = mysql_connect($db_host, $db_user, $db_pass) or die ('Error connecting to mysql');
	$db_name = 'brucemcm_v6';
	mysql_select_db($db_name, $con);
	
	$base_url = 'http://clients.verstonedigital.com/lilly/v6/'; // base site url
	$site_url = 'http://clients.verstonedigital.com/lilly/v6/admin/'; // base site url
	$files_path = '/home/brucemcm/public_html/clients/lilly/v6/'; // base site url
	$dir_path = '/home/brucemcm/public_html/clients/lilly/v6/'; // base site url
?>