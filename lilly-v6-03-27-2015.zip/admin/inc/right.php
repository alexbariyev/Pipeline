<div id="menu_right">
	<?php if(isset($_GET['page_id']) && $_GET['page_id'] != 1) { ?>
		<script type="text/javascript">
			$(document).ready(function(){
				$('#overflow-attrition').css('height', $('#overflow-container').height());
			});
		</script>
		<!--<div id="overflow-attrition">&nbsp;</div>-->
	<?php } ?>
	<div id="overflow-container">
		<div class="section_right">
			<h2><a href="#" onclick="editAttritionTitle(<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>); return false;" title="">Cells</a></h2>
			<p style="width: 100%; padding-bottom: 10px; float: left;"><a class="admin_add_attrition" href="#" onclick="addAttrition('<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>');">Add new cell</a></p>
			<?php if(!empty($attritions)) { ?>
				<ul class="molecule-info">
					<?php foreach($attritions as $att) { ?>
						<li onmouseout="hideCellActions(this);" onmouseover="showCellActions(this);" class="table_cell editable">
							<a class="<?php echo $att['bgColor']; ?>_cell tooltip" title="<?php echo !empty($att['name'])?$att['name']:''; ?>">
								<?php if(!empty($att['triangle']) && $att['triangle'] != 'none'){ ?>
									<img class="minfoimg" align="absmiddle" src="../img/<?php echo $att['triangle']; ?>.png" alt="" />
								<?php } ?>
								<label><?php echo !empty($att['name'])?$att['name']:''; ?></label>
							</a>
							<a href="#" onclick='editAttrition("<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>", "<?php echo $att['attrition_content_id']; ?>"); return false;' title="Edit attrition" class="cell-ops edit-cell">&nbsp;</a>
							<a href="#" onclick='deleteAttrition("<?php echo $att['attrition_content_id']; ?>"); return false;' title="Delete attrition" class="cell-ops delete-cell">&nbsp;</a>
						</li>
					<?php } ?>
				</ul>
			<?php } ?>
		</div>
	</div>
	<div class="section_right">
		<?php if(isset($_GET['page_id'])){ ?>
			<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_page_attrition_description" name="form_save_page_attrition_description" id="form_save_page_attrition_description">
				<p>
					<label>Description</label>
					<textarea name="page_attrition_description" id="page_attrition_description"><?php echo $data['page_attrition_description']?></textarea>
				</p>
				<p>
					<input type="submit" name="save_page_attrition_description" value="Save description" />
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
				</p>
			</form>
		<?php }elseif(isset($_GET['full_legend'])){ ?>
			<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_full_legend_description" name="form_save_full_legend_description" id="form_save_full_legend_description">
				<p>
					<label>Description</label>
					<textarea name="full_legend_description" id="full_legend_description"><?php echo $full_legend['description']?></textarea>
				</p>
				<p>
					<input type="submit" name="save_full_legend_description" value="Save description" />
				</p>
			</form>
		<?php } ?>
	</div>
	<div class="section_right admin-molecule-legend">
		<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_molecule_legend" name="form_save_molecule_legend" id="form_save_molecule_legend">
			<?php 
				if(!empty($molecule_legend)) { ?>
					<?php 
						$i = 0;
						foreach($molecule_legend as $l) { ?>
							<p>
								<img src="<?php echo $base_url; ?>img/<?php echo $l['legend_identifier']; ?>.png" alt="" />
								<input type="text" name="molecule_legend[<?php echo $i; ?>][legend_name]" value="<?php echo $l['legend_name']; ?>" />
								<input type="text" name="molecule_legend[<?php echo $i; ?>][legend_tooltip]" value="<?php echo $l['legend_tooltip']; ?>" />
								<input type="hidden" name="molecule_legend[<?php echo $i; ?>][legend_identifier]" value="<?php echo $l['legend_identifier']; ?>" alt="" />
							</p>
					<?php 
							$i++;

						} ?>
					<p><input style="width: auto;" type="submit" name="save_molecule_legend" value="Save" /></p>
					<input type="hidden" name="page_id" value="<?php echo isset($_GET['page_id'])?intval($_GET['page_id']):'1'; ?>" />
			<?php 
				} ?>
		</form>
	</div>
	
	<div class="section_right">
	<a id="full_legend_link" href="<?php echo $site_url; ?>index.php?full_legend">Full Legend</a>
	</div>
</div>