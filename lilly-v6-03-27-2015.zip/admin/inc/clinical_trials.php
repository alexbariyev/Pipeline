
<div id="content-center">
	<div class="content_section">
		<form method="post" action="<?php echo $site_url; ?>ajax.php?action=save_clinical_trials" name="form_save_clinical_trials" id="form_save_clinical_trials">
			<p>
				<label>Clinical trials</label>
			</p>
			<p>
				<textarea rows="20" cols="80" name="clinical_trials" id="clinical_trials"><?php echo $general['clinical_trials']; ?></textarea>
			</p>
			<p>
				<input type="submit" name="save_clinical_trials" value="Save clinical trials" />
			</p>
		</form>
	</div>
</div>